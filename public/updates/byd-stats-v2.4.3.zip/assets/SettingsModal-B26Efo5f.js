const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./MfgDateModal-Dwsvh1-3.js","./vendor-react-DvohKEV-.js","./vendor-i18n-B6d0pxtn.js","./vendor-capacitor-BixQsqqo.js","./vendor-charts-B2MWdnDF.js","./index-DvDRmn3e.js","./vendor-firebase-B75Ya_cL.js","./index-c-ne0ukR.css"])))=>i.map(i=>d[i]);
import{u as j,R as F,j as e,r as i,z as C}from"./vendor-react-DvohKEV-.js";import{f as A,e as ne,L as le,R as oe,D as de,g as ie,l as N,h as L,i as B,j as ce,k as I,m as _,Z as xe,T as me,n as ge,w as ue,o as be,p as he,q as pe,r as fe,s as ke,t as ve,E as je,v as ye,x as we,M as Ne}from"./index-DvDRmn3e.js";import{_ as Ce}from"./vendor-capacitor-BixQsqqo.js";import{t as W,v as G,z as Pe}from"./vendor-firebase-B75Ya_cL.js";import"./vendor-i18n-B6d0pxtn.js";import"./vendor-charts-B2MWdnDF.js";const Se=({googleSync:a})=>{const{t}=j(),{openModal:l,exportSyncData:x}=A(),[u,n]=F.useState(!1),[s,o]=F.useState(!1);F.useEffect(()=>{n(!1)},[a.userProfile?.imageUrl]);const m=a.userProfile?.imageUrl,r=m&&!u;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(ne,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[r?e.jsx("img",{src:m,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>n(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"}),e.jsx("span",{className:"text-[10px] font-medium text-green-600 dark:text-green-400",children:t("settings.connected")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(le,{className:"w-5 h-5"})})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(oe,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>l("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(de,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{o(!0);try{await x()}catch(c){N.error("Export failed:",c)}finally{o(!1)}},disabled:s,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(s?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[s?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(ie,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),s?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},Fe=F.lazy(()=>Ce(()=>import("./MfgDateModal-Dwsvh1-3.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)),Ee=()=>{const{t:a}=j(),{settings:t,updateSettings:l}=L(),{activeCar:x,updateCar:u,activeCarId:n}=B(),{stats:s,aiSoH:o}=A(),[m,r]=i.useState(!1),c=s?.summary?.sohData,g=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsx("input",{id:"carModel",name:"carModel",type:"text",value:x?.name||t?.carModel||"",onChange:d=>{const p=d.target.value;l({...t,carModel:p}),n&&u(n,{name:p})},placeholder:a("modals.addCarPlaceholder"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:d=>l({...t,licensePlate:d.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"insurancePolicy",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.insurancePolicy")}),e.jsx("input",{id:"insurancePolicy",name:"insurancePolicy",type:"text",value:t?.insurancePolicy||"",onChange:d=>l({insurancePolicy:d.target.value}),placeholder:"123456789",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:d=>l({...t,batterySize:parseFloat(d.target.value)||0}),onBlur:async()=>{if(x?.vin)try{const d=W(I,"bydVehicles",x.vin);await G(d,{batteryCapacity:t.batterySize})}catch(d){N.error("Error syncing battery capacity:",d)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(d=>e.jsx("button",{role:"radio","aria-checked":g===d,onClick:()=>{d!=="calculated"||t.mfgDate||r(!0),l({...t,sohMode:d})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(g===d?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:d==="ai"?"SoH IA":a(`settings.soh${d.charAt(0).toUpperCase()+d.slice(1)}`)},d))}),g==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:d=>l({...t,soh:parseInt(d.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>r(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(ce,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):g==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[c?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[o?.toFixed(1)||100,"%"]})]})})]}),e.jsx(F.Suspense,{fallback:null,children:m&&e.jsx(Fe,{isOpen:m,onClose:()=>r(!1),onSave:(d,p)=>{l({...t,mfgDate:d,mfgDateDisplay:p})},initialValue:t.mfgDateDisplay})})]})},De=()=>{const{t:a}=j(),{settings:t,updateSettings:l}=L(),{activeCar:x}=B(),{charges:u}=(function(){const{charges:r}=A();return{charges:r}})(),{avgElectricPrice:n,avgFuelPrice:s,electricStats:o,fuelStats:m}=i.useMemo(()=>{if(!u||u.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const r=u.filter(h=>!h.type||h.type==="electric"),c=u.filter(h=>h.type==="fuel"),g=r.reduce((h,v)=>h+(v.totalCost||0),0),d=r.reduce((h,v)=>h+(v.kwhCharged||0),0),p=d>0?g/d:0,k=c.reduce((h,v)=>h+(v.totalCost||0),0),f=c.reduce((h,v)=>h+(v.litersCharged||0),0);return{avgElectricPrice:p,avgFuelPrice:f>0?k/f:0,electricStats:{count:r.length,total:g,kwh:d},fuelStats:{count:c.length,total:k,liters:f}}},[u]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(r=>{const c=t.priceStrategy===r||!t.priceStrategy&&(r==="average"&&t.useCalculatedPrice||r==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>l({...t,priceStrategy:r,useCalculatedPrice:r==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(c?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:r!=="average"||u&&u.length!==0?"":a("settings.priceCalculatedNoData"),children:a(r==="custom"?"settings.priceCustom":r==="average"?"settings.priceCalculated":"settings.priceDynamics")},r)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?n.toFixed(3):t?.electricPrice||0,onChange:r=>l({...t,electricPrice:parseFloat(r.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(o.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:o.count,total:o.total.toFixed(2),kwh:o.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),x?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(r=>{const c=t.fuelPriceStrategy===r||!t.fuelPriceStrategy&&(r==="average"&&t.useCalculatedFuelPrice||r==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>l({...t,fuelPriceStrategy:r,useCalculatedFuelPrice:r==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(c?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:r==="average"&&m.count===0?a("settings.priceCalculatedNoData"):"",children:a(r==="custom"?"settings.priceCustom":r==="average"?"settings.priceCalculated":"settings.priceDynamics")},r)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?s.toFixed(3):t?.fuelPrice||1.5,onChange:r=>l({...t,fuelPrice:parseFloat(r.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(m.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:m.count,total:m.total.toFixed(2),liters:m.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},Te=()=>{const{t:a}=j(),{settings:t,updateSettings:l}=L(),x=i.useCallback((s,o,m)=>{const r=[...t.chargerTypes||[]];r[s]={...r[s],[o]:m},l({...t,chargerTypes:r})},[t,l]),u=i.useCallback(()=>{const s={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},o=[...t.chargerTypes||[],s];l({...t,chargerTypes:o})},[t,l,a]),n=i.useCallback(s=>{const o=(t.chargerTypes||[]).filter((m,r)=>r!==s);l({...t,chargerTypes:o})},[t,l]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:_},children:e.jsx(xe,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((s,o)=>{const m=`charger_${o}_name`,r=`charger_${o}_speed`,c=`charger_${o}_efficiency`;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:m,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:m,name:m,type:"text",value:s?.name||"",onChange:g=>x(o,"name",g.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),e.jsx("button",{onClick:()=>n(o),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(me,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:r,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:r,name:r,type:"number",step:"0.1",value:s?.speedKw||0,onChange:g=>x(o,"speedKw",parseFloat(g.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:c,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:c,name:c,type:"number",step:"0.01",min:"0",max:"1",value:s?.efficiency||0,onChange:g=>x(o,"efficiency",parseFloat(g.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]},s.id)}),e.jsxs("button",{onClick:u,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]}),e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:_},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating||8,onChange:s=>l({...t,homeChargerRating:parseInt(s.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating||8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("label",{id:"offPeakLabel",className:"text-sm text-slate-700 dark:text-slate-300",children:a("settings.offPeakEnabled","Tarifa Valle (Horario Reducido)")}),e.jsx("button",{"aria-labelledby":"offPeakLabel",onClick:()=>{l({...t,offPeakEnabled:!t.offPeakEnabled})},className:"relative inline-flex h-6 w-11 items-center rounded-full transition-colors "+(t.offPeakEnabled?"bg-emerald-500":"bg-slate-300 dark:bg-slate-600"),children:e.jsx("span",{className:"inline-block h-4 w-4 transform rounded-full bg-white transition-transform "+(t.offPeakEnabled?"translate-x-6":"translate-x-1")})})]}),t.offPeakEnabled&&e.jsxs("div",{className:"space-y-3 pl-2 border-l-2 border-slate-200 dark:border-slate-600",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekday","Horario L-V")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStart",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStart",name:"offPeakStart",type:"time",value:t.offPeakStart||"00:00",onChange:s=>l({...t,offPeakStart:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEnd",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEnd",name:"offPeakEnd",type:"time",value:t.offPeakEnd||"08:00",onChange:s=>l({...t,offPeakEnd:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekend","Horario Fin de Semana")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStartWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStartWeekend",name:"offPeakStartWeekend",type:"time",value:t.offPeakStartWeekend||t.offPeakStart||"00:00",onChange:s=>l({...t,offPeakStartWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEndWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEndWeekend",name:"offPeakEndWeekend",type:"time",value:t.offPeakEndWeekend||t.offPeakEnd||"08:00",onChange:s=>l({...t,offPeakEndWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakPrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.offPeakPrice","Precio Valle (€/kWh)")}),e.jsx("input",{id:"offPeakPrice",name:"offPeakPrice",type:"number",step:"0.001",value:t.offPeakPrice||.05,onChange:s=>l({...t,offPeakPrice:parseFloat(s.target.value)||0}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:"0.05"})]})]})]})]})]})},ze=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],Ae=({username:a,password:t,countryCode:l,controlPin:x,isLoading:u,onUsernameChange:n,onPasswordChange:s,onCountryCodeChange:o,onControlPinChange:m,onConnect:r})=>{const{t:c}=j();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:c("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:g=>n(g.target.value),placeholder:c("settings.emailPlaceholder"),disabled:u})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:c("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:g=>s(g.target.value),placeholder:"••••••••",disabled:u})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:c("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:l,onChange:g=>o(g.target.value),disabled:u,children:ze.map(g=>e.jsx("option",{value:g.code,children:g.name},g.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:c("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:x,onChange:g=>m(g.target.value),placeholder:"1234",maxLength:6,disabled:u}),e.jsx("span",{className:"form-hint",children:"Necesario para bloquear/desbloquear y control de clima"})]}),e.jsx("button",{className:"btn-connect",onClick:r,disabled:u||!a||!t,children:u?"Conectando...":"Conectar con BYD"})]})},Le=({connectedVin:a,connectedVehicles:t,isLoading:l,autoRegisterCharges:x,heartbeatEnabled:u,abrpToken:n,abrpSaving:s,onDisconnect:o,onAutoRegisterChange:m,onHeartbeatChange:r,onAbrpTokenChange:c,onSaveAbrpToken:g,onConnectionTap:d})=>{const{t:p}=j();return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:d,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),t.length>0&&e.jsx("span",{className:"vehicle-name",children:t[0].name||t[0].model})]})]}),e.jsx("button",{className:"btn-disconnect w-full",onClick:o,disabled:l,children:"Desconectar"}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:p("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:p("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:x,onChange:k=>{const f=k.target.checked;m(f),localStorage.setItem("byd_auto_register_charges",String(f)),C.success(p(f?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:p("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:p("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:u,onChange:k=>(async f=>{r(f);try{await G(W(I,"bydVehicles",a),{heartbeatEnabled:f}),C.success(p(f?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(h){N.error("Error updating heartbeatEnabled:",h),r(!f),C.error(p("errors.genericWithMessage",{message:h.message||p("errors.cannotSave")}))}})(k.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:"ABRP — A Better Route Planner"}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:"Introduce tu token de ABRP para enviar telemetría en tiempo real. Encuéntralo en ABRP → Perfil → «Link car»."}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("input",{type:"password",value:n,onChange:k=>c(k.target.value),placeholder:"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"flex-1 px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:g,disabled:s,className:"px-3 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:s?"...":"Guardar"})]}),n&&e.jsx("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:"✓ Telemetría ABRP activa"})]})]})},Me=({connectedVin:a,debugDump:t,onClose:l})=>{const{t:x}=j();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),C.success(x("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:l,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},Re=({onConnectionChange:a})=>{const t=(l=>{const{t:x}=j(),[u,n]=i.useState(!1),[s,o]=i.useState(null),[m,r]=i.useState([]),[c,g]=i.useState(""),[d,p]=i.useState(""),[k,f]=i.useState("ES"),[h,v]=i.useState(""),[Y,P]=i.useState(!1),[K,y]=i.useState(null),[J,M]=i.useState(null),[q,Z]=i.useState(()=>localStorage.getItem("byd_auto_register_charges")==="true"),[Q,H]=i.useState(!1),[E,V]=i.useState(""),[X,U]=i.useState(!1),[ee,D]=i.useState(null),T=i.useRef(0),S=i.useRef(null),z=i.useRef(l);z.current=l,i.useEffect(()=>{const b=localStorage.getItem("byd_connected_vin"),w=localStorage.getItem("byd_connected_vehicles");if(b&&(o(b),n(!0),z.current?.(!0,b)),w)try{r(JSON.parse(w))}catch{}},[]),i.useEffect(()=>{s&&Pe(W(I,"bydVehicles",s)).then(b=>{b.exists()&&(H(b.data().heartbeatEnabled===!0),V(b.data().abrpUserToken||""))}).catch(()=>{})},[s]);const te=i.useCallback(async()=>{if(s){U(!0);try{await ge(s,E.trim()),C.success(E.trim()?x("settings.abrp.tokenSaved"):x("settings.abrp.tokenRemoved"))}catch(b){N.error("Error saving ABRP token:",b),C.error(x("settings.abrp.tokenError"))}finally{U(!1)}}},[s,E,x]),ae=i.useCallback(async()=>{if(c&&d){P(!0),y(null),M(null);try{const b=await ue()||"dev-user",w=await be(c,d,k,h||void 0,b);if(w.success&&w.vehicles.length>0){const R=w.vehicles[0].vin;o(R),r(w.vehicles),n(!0),localStorage.setItem("byd_connected_vin",R),localStorage.setItem("byd_connected_vehicles",JSON.stringify(w.vehicles)),M(`Conectado: ${w.vehicles.map($=>$.name||$.model).join(", ")}`),p(""),v(""),z.current?.(!0,R)}else y("No se encontraron vehículos en la cuenta")}catch(b){N.error("BYD connect error:",b),y(b instanceof Error?b.message:"Error al conectar con BYD")}finally{P(!1)}}else y("Por favor introduce usuario y contraseña")},[c,d,k,h]),se=i.useCallback(async()=>{if(s){P(!0),y(null);try{await he(s),o(null),r([]),n(!1),D(null),localStorage.removeItem("byd_connected_vin"),localStorage.removeItem("byd_connected_vehicles"),localStorage.removeItem("byd_auto_register_charges"),M("Desconectado correctamente"),z.current?.(!1)}catch(b){N.error("BYD disconnect error:",b),y(b instanceof Error?b.message:"Error al desconectar")}finally{P(!1)}}},[s]),O=i.useCallback(async()=>{if(s){P(!0),y(null),D(null);try{const b=await pe(s);b.success?(D(b.dump),C.success(x("settings.debug.dumpSuccess"))):y("Error al obtener dump")}catch(b){N.error("BYD dump error:",b),y(b instanceof Error?b.message:"Error al obtener dump")}finally{P(!1)}}},[s,x]),re=i.useCallback(()=>{T.current+=1;const b=T.current;S.current&&clearTimeout(S.current),S.current=setTimeout(()=>{T.current=0},fe),b>=10&&(T.current=0,S.current&&clearTimeout(S.current),O())},[O]);return{isConnected:u,connectedVin:s,connectedVehicles:m,username:c,password:d,countryCode:k,controlPin:h,setUsername:g,setPassword:p,setCountryCode:f,setControlPin:v,isLoading:Y,error:K,success:J,autoRegisterCharges:q,setAutoRegisterCharges:Z,heartbeatEnabled:Q,setHeartbeatEnabled:H,abrpToken:E,setAbrpToken:V,abrpSaving:X,debugDump:ee,clearDebugDump:i.useCallback(()=>D(null),[]),handleConnect:ae,handleDisconnect:se,handleSaveAbrpToken:te,handleConnectionTap:re}})(a);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"BYD Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),t.isConnected&&t.connectedVin&&e.jsx(Le,{connectedVin:t.connectedVin,connectedVehicles:t.connectedVehicles,isLoading:t.isLoading,autoRegisterCharges:t.autoRegisterCharges,heartbeatEnabled:t.heartbeatEnabled,abrpToken:t.abrpToken,abrpSaving:t.abrpSaving,onDisconnect:t.handleDisconnect,onAutoRegisterChange:t.setAutoRegisterCharges,onHeartbeatChange:t.setHeartbeatEnabled,onAbrpTokenChange:t.setAbrpToken,onSaveAbrpToken:t.handleSaveAbrpToken,onConnectionTap:t.handleConnectionTap}),t.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),t.error]}),t.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),t.success]}),!t.isConnected&&e.jsx(Ae,{username:t.username,password:t.password,countryCode:t.countryCode,controlPin:t.controlPin,isLoading:t.isLoading,onUsernameChange:t.setUsername,onPasswordChange:t.setPassword,onCountryCodeChange:t.setCountryCode,onControlPinChange:t.setControlPin,onConnect:t.handleConnect}),t.isConnected&&t.connectedVin&&t.debugDump&&e.jsx(Me,{connectedVin:t.connectedVin,debugDump:t.debugDump,onClose:t.clearDebugDump})]}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},_e=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),Be=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),Ie=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),We=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),He=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),Ve=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),Ue=()=>{const{t:a,i18n:t}=j(),{settings:l,updateSettings:x}=L(),u=i.useCallback(n=>{t.changeLanguage(n)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"flex flex-wrap gap-2",children:ke.map(n=>e.jsxs("button",{role:"radio","aria-checked":t.language===n.code||t.language?.startsWith(n.code),onClick:()=>u(n.code),className:"py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 border "+(t.language===n.code||t.language?.startsWith(n.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"20px",height:"15px"},children:n.code==="gl"?e.jsx(_e,{className:"w-full h-full rounded-sm"}):n.code==="ca"?e.jsx(Be,{className:"w-full h-full rounded-sm"}):n.code==="eu"?e.jsx(Ie,{className:"w-full h-full rounded-sm"}):n.code==="es"?e.jsx(We,{className:"w-full h-full rounded-sm"}):n.code==="en"?e.jsx(He,{className:"w-full h-full rounded-sm"}):n.code==="pt"?e.jsx(Ve,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:n.flag})}),n.name]},n.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(n=>e.jsx("button",{role:"radio","aria-checked":l?.theme===n,onClick:()=>x({...l,theme:n}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(l?.theme===n?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(n==="auto"?"settings.themeAuto":n==="light"?"settings.themeLight":"settings.themeDark")},n))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:ve.filter(n=>n!=="overview").map(n=>{const s=(l.hiddenTabs||[]).includes(n);return e.jsxs("button",{onClick:()=>{const o=l.hiddenTabs||[],m=s?o.filter(r=>r!==n):[...o,n];x({...l,hiddenTabs:m})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(s?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${n}`)}),s?e.jsx(ye,{className:"w-4 h-4"}):e.jsx(je,{className:"w-4 h-4"})]},n)})})]})]})]})},qe=({onClose:a})=>{const{t}=j(),{googleSync:l,closeModal:x,openModal:u}=A(),{updateCar:n,activeCarId:s}=B(),{isNative:o}=we(),m=()=>{a?a():x("settings")};return e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(Ne,{title:t("settings.title"),onClose:m}),e.jsxs("div",{className:"space-y-6 mt-4",children:[e.jsx(Ee,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(De,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Te,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Ue,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Se,{googleSync:l}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),o&&e.jsxs(e.Fragment,{children:[e.jsx(Re,{onConnectionChange:(r,c)=>{r&&c&&s?n(s,{vin:c,connectorType:"pybyd"}):!r&&s&&n(s,{vin:void 0,connectorType:void 0})}}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsxs("div",{className:"p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl flex items-center justify-between group",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800 flex items-center justify-center",children:e.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",className:"w-5 h-5 text-slate-600 dark:text-slate-400",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("circle",{cx:"12",cy:"12",r:"7"}),e.jsx("polyline",{points:"12 9 12 12 13.5 13.5"}),e.jsx("path",{d:"M16.51 17.35l-.35 3.83a2 2 0 0 1-2 1.82H9.84a2 2 0 0 1-2-1.82l-.35-3.83m9.02-10.7l.35-3.83a2 2 0 0 0-2-1.82H9.84a2 2 0 0 0-2 1.82l.35 3.83"})]})}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-bold text-slate-800 dark:text-white text-sm",children:t("modals.wearOs")}),e.jsx("p",{className:"text-xs text-slate-500",children:t("modals.wearOsInstall")})]})]}),e.jsx("button",{onClick:()=>x("settings"),onMouseDown:()=>u("wearOSSetup"),className:"px-4 py-2 bg-slate-800 dark:bg-slate-700 text-white rounded-xl text-xs font-bold hover:scale-105 transition-transform",children:"Configurar"})]})]})]}),e.jsx("button",{onClick:m,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:_},children:t("common.save")})]})})};export{qe as default};
