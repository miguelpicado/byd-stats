const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./MfgDateModal-DISzheop.js","./vendor-react-BpBHRb8g.js","./vendor-i18n-sZC3GtoX.js","./vendor-capacitor-CnICfPQy.js","./vendor-firebase-C8R0NUg4.js","./vendor-charts-B2MWdnDF.js","./index-DSVsM_ik.js","./index-BIf3N2Ic.css","./AbrpHelpModal-CvhlV2D3.js","./BaseModal-PIjjBcvx.js"])))=>i.map(i=>d[i]);
import{u as F,R as M,j as e,r as o,n as re,z as A}from"./vendor-react-BpBHRb8g.js";import{f as Y,e as ye,L as je,R as Ne,D as we,h as Ce,l as T,w as ne,i as O,j as q,k as G,m as Se,n as Pe,o as Ee,p as De,q as Z,Z as Te,T as Fe,r as Ae,s as ze,t as Ie,v as Me,x as Ve,y as _e,z as Re,E as Le,G as Be,I as We,J as He,K as Ue,M as $e,N as Oe}from"./index-DSVsM_ik.js";import{_ as le}from"./vendor-capacitor-CnICfPQy.js";import{Y as Ye,U as qe,X as Ge,a2 as Je,S as Ke,Q as Ze,a7 as Q,ae as oe,af as Qe}from"./vendor-firebase-C8R0NUg4.js";import{i as Xe}from"./batteryCalculations-BaqeSYWG.js";import{B as et}from"./BydVehiclePickerModal-D7Hjt1jn.js";import"./vendor-i18n-sZC3GtoX.js";import"./vendor-charts-B2MWdnDF.js";const tt=({googleSync:a})=>{const{t}=F(),{openModal:i,exportSyncData:b}=Y(),[m,n]=M.useState(!1),[x,h]=M.useState(!1);M.useEffect(()=>{n(!1)},[a.userProfile?.imageUrl]);const p=a.userProfile?.imageUrl,s=p&&!m;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(ye,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[s?e.jsx("img",{src:p,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>n(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full "+(a.isDriveReady?"bg-green-500 animate-pulse":"bg-amber-400")}),e.jsx("span",{className:"text-[10px] font-medium "+(a.isDriveReady?"text-green-600 dark:text-green-400":"text-amber-600 dark:text-amber-400"),children:a.isDriveReady?t("settings.connected"):t("settings.driveDisconnected","Drive desconectado")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(je,{className:"w-5 h-5"})})]}),!a.isDriveReady&&e.jsxs("div",{className:"mb-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl",children:[e.jsx("p",{className:"text-xs text-amber-700 dark:text-amber-400 font-medium mb-2",children:t("settings.driveSessionExpired","La sesión de Drive ha expirado")}),e.jsx("button",{onClick:a.login,className:"w-full py-2 px-3 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-all active:scale-[0.98]",children:t("settings.reconnectDrive","Reconectar Google Drive")})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(Ne,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>i("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(we,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{h(!0);try{await b()}catch(r){T.error("Export failed:",r)}finally{h(!1)}},disabled:x,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(x?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[x?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(Ce,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),x?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},at=M.lazy(()=>le(()=>import("./MfgDateModal-DISzheop.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)),st=()=>{const{t:a}=F(),{settings:t,updateSettings:i}=q(),{activeCar:b,updateCar:m,activeCarId:n,cars:x}=G(),{stats:h,aiSoH:p}=Y(),[s,r]=o.useState(!1),{vehicles:u,loading:k}=(function(){const[l,g]=o.useState([]),[C,P]=o.useState(!0);return o.useEffect(()=>{let D=null,w=!1;return(async()=>{const S=await ne();if(w||!S)return void P(!1);const E=Ye(Ge(O,"bydVehicles"),qe("userId","==",S));D=Je(E,V=>{const I=[];V.forEach(L=>{const _=L.data();I.push({vin:L.id,modelName:_.modelName,vehicleType:_.vehicleType,lastSoC:_.lastSoC})}),g(I),P(!1)},V=>{T.warn("[useUserVehicles] snapshot error:",V),P(!1)})})(),()=>{w=!0,D?.()}},[]),{vehicles:l,loading:C}})(),[N,d]=o.useState(null),j=o.useMemo(()=>{const l=new Map;return u.forEach(g=>{l.set(g.vin,{vin:g.vin,label:g.modelName?`${g.modelName} · ${g.vin}`:g.vin})}),b?.vin&&!l.has(b.vin)&&l.set(b.vin,{vin:b.vin,label:b.vin}),Array.from(l.values())},[u,b?.vin]),f=h?.summary?.sohData,v=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:l=>i({...t,carModel:l.target.value,carColor:void 0}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),Se.map(({model:l})=>e.jsx("option",{value:l,children:l},l))]}),(()=>{const l=Pe(t?.carModel);return l?e.jsxs("div",{className:"mt-3",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carColor","Color del coche")}),e.jsx("div",{className:"flex flex-wrap gap-3",children:l.colors.map(g=>e.jsx("button",{onClick:()=>i({...t,carColor:g.id}),className:"w-8 h-8 rounded-full border-2 transition-all cursor-pointer shadow-sm "+(t?.carColor===g.id?"border-red-500 scale-110 shadow-md ring-2 ring-red-500/20":"border-slate-200 dark:border-slate-600 hover:scale-105"),style:{backgroundColor:g.hex},title:g.name,type:"button","aria-label":`Seleccionar color ${g.name}`},g.id))})]}):null})()]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:b?.name||t?.carName||"",onChange:l=>{const g=l.target.value;i({...t,carName:g}),n&&m(n,{name:g})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carVin",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.vin","VIN asociado")}),e.jsxs("select",{id:"carVin",name:"carVin",value:b?.vin||"",onChange:l=>(g=>{if(!n)return;const C=g||void 0;C&&x.forEach(P=>{P.id!==n&&P.vin===C&&m(P.id,{vin:void 0,connectorType:void 0})}),m(n,{vin:C,connectorType:C?"pybyd":void 0})})(l.target.value),disabled:!n||k&&j.length===0,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 font-mono text-sm disabled:opacity-50",children:[e.jsx("option",{value:"",children:a("settings.vinNone","Sin VIN asociado")}),j.map(l=>e.jsx("option",{value:l.vin,children:l.label},l.vin))]}),u.length>1&&e.jsxs("div",{className:"mt-4",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.otherVehicles","Otros vehículos en tu cuenta")}),e.jsx("div",{className:"space-y-2",children:u.filter(l=>l.vin!==b?.vin).map(l=>e.jsxs("div",{className:"flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700",children:[e.jsx("span",{className:"text-sm font-mono text-slate-700 dark:text-slate-300",children:l.vin}),e.jsx("button",{type:"button",disabled:N===l.vin,onClick:()=>(async g=>{if(confirm(`¿Estás seguro de que quieres desvincular y borrar de la nube el vehículo ${g}? Esta acción eliminará permanentemente su historial si no hiciste copia en Drive.`)){d(g);try{const C=Ke(void 0,"europe-west1");await Ze(C,"bydDetachVehicleV2")({vin:g}),re.success(a("settings.vehicleDetached","Vehículo desvinculado correctamente")),b?.vin===g&&n&&m(n,{vin:void 0,connectorType:void 0})}catch(C){T.error("Error detaching vehicle:",C),re.error(C.message||"Error al desvincular el vehículo")}finally{d(null)}}})(l.vin),className:"text-xs font-medium text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 disabled:opacity-50",children:N===l.vin?a("common.loading","Cargando..."):a("settings.detachVehicle","Desasociar de mi cuenta")})]},l.vin))})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:l=>i({...t,licensePlate:l.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:l=>i({...t,batterySize:parseFloat(l.target.value)||0}),onBlur:async()=>{if(b?.vin)try{const l=Q(O,"bydVehicles",b.vin),g=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!g||g<=0)return;await oe(l,{batteryCapacity:g,lastBatteryCapacity:g})}catch(l){T.error("Error syncing battery capacity:",l)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(l=>e.jsx("button",{role:"radio","aria-checked":v===l,onClick:()=>{l!=="calculated"||t.mfgDate||r(!0),i({...t,sohMode:l})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(v===l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:l==="ai"?"SoH IA":a(`settings.soh${l.charAt(0).toUpperCase()+l.slice(1)}`)},l))}),v==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:l=>i({...t,soh:parseInt(l.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>r(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Ee,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):v==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[f?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[p?.toFixed(1)||100,"%"]})]})})]}),e.jsx(M.Suspense,{fallback:null,children:s&&e.jsx(at,{isOpen:s,onClose:()=>r(!1),onSave:(l,g)=>{i({...t,mfgDate:l,mfgDateDisplay:g})},initialValue:t.mfgDateDisplay})})]})},rt=()=>{const{t:a}=F(),{settings:t,updateSettings:i}=q(),{activeCar:b}=G(),{charges:m}=(function(){const{charges:s}=Y();return{charges:s}})(),{avgElectricPrice:n,avgFuelPrice:x,electricStats:h,fuelStats:p}=o.useMemo(()=>{if(!m||m.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const s=m.filter(f=>!f.type||f.type==="electric"),r=m.filter(f=>f.type==="fuel"),u=s.reduce((f,v)=>f+(v.totalCost||0),0),k=s.reduce((f,v)=>f+(v.kwhCharged||0),0),N=k>0?u/k:0,d=r.reduce((f,v)=>f+(v.totalCost||0),0),j=r.reduce((f,v)=>f+(v.litersCharged||0),0);return{avgElectricPrice:N,avgFuelPrice:j>0?d/j:0,electricStats:{count:s.length,total:u,kwh:k},fuelStats:{count:r.length,total:d,liters:j}}},[m]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const r=t.priceStrategy===s||!t.priceStrategy&&(s==="average"&&t.useCalculatedPrice||s==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>i({...t,priceStrategy:s,useCalculatedPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(r?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s!=="average"||m&&m.length!==0?"":a("settings.priceCalculatedNoData"),children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?n.toFixed(3):t?.electricPrice||0,onChange:s=>i({...t,electricPrice:parseFloat(s.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(h.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:h.count,total:h.total.toFixed(2),kwh:h.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),b?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const r=t.fuelPriceStrategy===s||!t.fuelPriceStrategy&&(s==="average"&&t.useCalculatedFuelPrice||s==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>i({...t,fuelPriceStrategy:s,useCalculatedFuelPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(r?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s==="average"&&p.count===0?a("settings.priceCalculatedNoData"):"",children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?x.toFixed(3):t?.fuelPrice||1.5,onChange:s=>i({...t,fuelPrice:parseFloat(s.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(p.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:p.count,total:p.total.toFixed(2),liters:p.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},nt=()=>{const{t:a}=F(),{settings:t,updateSettings:i}=q(),{charges:b}=De(),m=o.useMemo(()=>{const s=t.batterySize,r=typeof s=="string"?parseFloat(s):Number(s);return r>0?r:0},[t.batterySize]),n=o.useMemo(()=>{if(!m||!b?.length)return{};const s={};for(const r of t.chargerTypes??[]){const u=Xe(b,m,r.id);u&&(s[r.id]=u)}return s},[b,m,t.chargerTypes]),x=o.useCallback((s,r,u)=>{const k=[...t.chargerTypes||[]];k[s]={...k[s],[r]:u},i({...t,chargerTypes:k})},[t,i]),h=o.useCallback(()=>{const s={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},r=[...t.chargerTypes||[],s];i({...t,chargerTypes:r})},[t,i,a]),p=o.useCallback(s=>{const r=(t.chargerTypes||[]).filter((u,k)=>k!==s);i({...t,chargerTypes:r})},[t,i]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:Z},children:e.jsx(Te,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((s,r)=>{const u=`charger_${r}_name`,k=`charger_${r}_speed`,N=`charger_${r}_efficiency`,d=n[s.id],j=s?.efficiency||0,f=d&&Math.abs(d.value-j)>=.01;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:u,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:u,name:u,type:"text",value:s?.name||"",onChange:v=>x(r,"name",v.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),e.jsx("button",{onClick:()=>p(r),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(Fe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:k,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:k,name:k,type:"number",step:"0.1",value:s?.speedKw||0,onChange:v=>x(r,"speedKw",parseFloat(v.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:N,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:N,name:N,type:"number",step:"0.01",min:"0",max:"1",value:s?.efficiency||0,onChange:v=>x(r,"efficiency",parseFloat(v.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),f&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*d.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",d.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>x(r,"efficiency",d.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},s.id)}),e.jsxs("button",{onClick:h,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]}),e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:Z},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating||8,onChange:s=>i({...t,homeChargerRating:parseInt(s.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating||8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("label",{id:"offPeakLabel",className:"text-sm text-slate-700 dark:text-slate-300",children:a("settings.offPeakEnabled","Tarifa Valle (Horario Reducido)")}),e.jsx("button",{"aria-labelledby":"offPeakLabel",onClick:()=>{i({...t,offPeakEnabled:!t.offPeakEnabled})},className:"relative inline-flex h-6 w-11 items-center rounded-full transition-colors "+(t.offPeakEnabled?"bg-emerald-500":"bg-slate-300 dark:bg-slate-600"),children:e.jsx("span",{className:"inline-block h-4 w-4 transform rounded-full bg-white transition-transform "+(t.offPeakEnabled?"translate-x-6":"translate-x-1")})})]}),t.offPeakEnabled&&e.jsxs("div",{className:"space-y-3 pl-2 border-l-2 border-slate-200 dark:border-slate-600",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekday","Horario L-V")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStart",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStart",name:"offPeakStart",type:"time",value:t.offPeakStart||"00:00",onChange:s=>i({...t,offPeakStart:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEnd",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEnd",name:"offPeakEnd",type:"time",value:t.offPeakEnd||"08:00",onChange:s=>i({...t,offPeakEnd:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekend","Horario Fin de Semana")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStartWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStartWeekend",name:"offPeakStartWeekend",type:"time",value:t.offPeakStartWeekend||t.offPeakStart||"00:00",onChange:s=>i({...t,offPeakStartWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEndWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEndWeekend",name:"offPeakEndWeekend",type:"time",value:t.offPeakEndWeekend||t.offPeakEnd||"08:00",onChange:s=>i({...t,offPeakEndWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakPrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.offPeakPrice","Precio Valle (€/kWh)")}),e.jsx("input",{id:"offPeakPrice",name:"offPeakPrice",type:"number",step:"0.001",value:t.offPeakPrice||.05,onChange:s=>i({...t,offPeakPrice:parseFloat(s.target.value)||0}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:"0.05"})]})]})]})]})]})},lt=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],ot=({username:a,password:t,countryCode:i,controlPin:b,isLoading:m,onUsernameChange:n,onPasswordChange:x,onCountryCodeChange:h,onControlPinChange:p,onConnect:s})=>{const{t:r}=F();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:r("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:u=>n(u.target.value),placeholder:r("settings.emailPlaceholder"),disabled:m})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:r("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:u=>x(u.target.value),placeholder:"••••••••",disabled:m})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:r("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:i,onChange:u=>h(u.target.value),disabled:m,children:lt.map(u=>e.jsx("option",{value:u.code,children:u.name},u.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:r("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:b,onChange:u=>p(u.target.value),placeholder:"1234",maxLength:6,disabled:m}),e.jsx("span",{className:"form-hint",children:"Necesario para bloquear/desbloquear y control de clima"})]}),e.jsx("button",{className:"btn-connect",onClick:s,disabled:m||!a||!t,children:m?"Conectando...":"Conectar con BYD"})]})},it=M.lazy(()=>le(()=>import("./AbrpHelpModal-CvhlV2D3.js"),__vite__mapDeps([8,1,2,3,4,5,9,6,7]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),dt=({connectedVin:a,connectedVehicles:t,isLoading:i,autoRegisterCharges:b,heartbeatEnabled:m,hasAbrpToken:n,abrpToken:x,abrpSaving:h,onDisconnect:p,onAutoRegisterChange:s,onHeartbeatChange:r,onAbrpTokenChange:u,onSaveAbrpToken:k,onConnectionTap:N})=>{const{t:d}=F(),[j,f]=o.useState(!1),[v,l]=o.useState(""),[g,C]=o.useState(!1),P=_e(a),D=P?.controlPinStatus;return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:N,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),t.length>0&&e.jsx("span",{className:"vehicle-name",children:t[0].name||t[0].model})]})]}),e.jsx("button",{className:"btn-disconnect w-full",onClick:p,disabled:i,children:"Desconectar"}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:d("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:d("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:b,onChange:w=>{const S=w.target.checked;s(S),localStorage.setItem("byd_auto_register_charges",String(S)),A.success(d(S?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:d("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:d("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:m,onChange:w=>(async S=>{r(S);try{await oe(Q(O,"bydVehicles",a),{heartbeatEnabled:S}),A.success(d(S?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(E){T.error("Error updating heartbeatEnabled:",E),r(!S),A.error(d("errors.genericWithMessage",{message:E.message||d("errors.cannotSave")}))}})(w.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:d("settings.pin.title","PIN de control")}),D==="set"&&e.jsxs("span",{className:"text-xs font-medium text-green-600 dark:text-green-400",children:["✓ ",d("settings.pin.statusSet","Configurado")]}),D==="invalid"&&e.jsxs("span",{className:"text-xs font-medium text-red-600 dark:text-red-400",children:["✗ ",d("settings.pin.statusInvalid","Incorrecto")]}),(D==="not_set"||D===void 0)&&e.jsx("span",{className:"text-xs font-medium text-amber-600 dark:text-amber-400",children:d("settings.pin.statusNotSet","Sin configurar")})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:d("settings.pin.desc","Necesario para bloquear/desbloquear y controlar el clima. Sin él las acciones rápidas quedan desactivadas.")}),D==="invalid"&&e.jsx("div",{className:"mb-3 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg p-2",children:d("settings.pin.invalidWarning","El PIN guardado es incorrecto. Introdúcelo de nuevo.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:v,onChange:w=>l(w.target.value.replace(/\D/g,"").slice(0,6)),placeholder:D==="set"?d("settings.pin.placeholderChange","Escribe el PIN para cambiarlo"):d("settings.pin.placeholder","Ej. 123456"),inputMode:"numeric",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:async()=>{const w=v.trim();if(w){C(!0);try{await Re(a,w),l(""),A.success(d("settings.pin.saved","PIN de control guardado"))}catch(S){T.error("[BydIntegrationSettings] Error saving PIN:",S),A.error(d("errors.genericWithMessage",{message:S.message||d("errors.cannotSave")}))}finally{C(!1)}}},disabled:g||!v.trim(),className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:g?"...":d("common.save","Guardar")})]})]}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>f(!0),"aria-label":d("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:d("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:x,onChange:w=>u(w.target.value),placeholder:n?d("abrp.tokenPlaceholderSet","Token guardado — escribe uno nuevo para reemplazar"):"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:k,disabled:h,className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:h?"...":d("common.save","Guardar")})]}),n&&!x&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",d("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsx(M.Suspense,{fallback:null,children:j&&e.jsx(it,{isOpen:j,onClose:()=>f(!1)})})]})},ct=({connectedVin:a,debugDump:t,onClose:i})=>{const{t:b}=F();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),A.success(b("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:i,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},mt=({onConnectionChange:a})=>{const t=(x=>{const{t:h}=F(),[p,s]=o.useState(!1),[r,u]=o.useState(null),[k,N]=o.useState([]),[d,j]=o.useState(""),[f,v]=o.useState(""),[l,g]=o.useState("ES"),[C,P]=o.useState(""),[D,w]=o.useState(!1),[S,E]=o.useState(null),[V,I]=o.useState(null),[L,_]=o.useState(()=>localStorage.getItem("byd_auto_register_charges")==="true"),[ie,X]=o.useState(!1),[de,ee]=o.useState(!1),[J,te]=o.useState(""),[ce,ae]=o.useState(!1),[me,B]=o.useState(null),[xe,W]=o.useState(null),H=o.useRef(0),R=o.useRef(null),U=o.useRef(x);U.current=x,o.useEffect(()=>{const c=localStorage.getItem("byd_connected_vin"),y=localStorage.getItem("byd_connected_vehicles");if(c&&(u(c),s(!0),U.current?.(!0,c)),y)try{N(JSON.parse(y))}catch{}},[]),o.useEffect(()=>{r&&Qe(Q(O,"bydVehicles",r)).then(c=>{c.exists()&&(X(c.data().heartbeatEnabled===!0),ee(c.data().hasAbrpToken===!0))}).catch(()=>{})},[r]);const ue=o.useCallback(async()=>{if(r){ae(!0);try{const c=J.trim();await Ae(r,c),ee(!!c),te(""),A.success(h(c?"settings.abrp.tokenSaved":"settings.abrp.tokenRemoved"))}catch(c){T.error("Error saving ABRP token:",c),A.error(h("settings.abrp.tokenError"))}finally{ae(!1)}}},[r,J,h]),$=o.useCallback((c,y)=>{u(c),N(y),s(!0),localStorage.setItem("byd_connected_vin",c),localStorage.setItem("byd_connected_vehicles",JSON.stringify(y));const z=y.find(K=>K.vin===c);I(`Conectado: ${z?.name||z?.model||c}`),v(""),P(""),U.current?.(!0,c)},[]),ge=o.useCallback(c=>{W(y=>y&&y.find(z=>z.vin===c)?($(c,y),null):y)},[$]),be=o.useCallback(c=>{W(y=>{if(!y)return y;const z=y.find(ke=>ke.vin===c);if(!z)return y;u(c),N(y),s(!0),localStorage.setItem("byd_connected_vin",c),localStorage.setItem("byd_connected_vehicles",JSON.stringify(y));const K=z.name||z.model||c;return I(`Conectado: ${K}`),v(""),P(""),null})},[]),he=o.useCallback(()=>{W(null)},[]),pe=o.useCallback(async()=>{if(d&&f){w(!0),E(null),I(null);try{const c=await ne()||"dev-user",y=await ze(d,f,l,C||void 0,c);y.success&&y.vehicles.length>0?y.vehicles.length===1?$(y.vehicles[0].vin,y.vehicles):W(y.vehicles):E("No se encontraron vehículos en la cuenta")}catch(c){T.error("BYD connect error:",c),E(c instanceof Error?c.message:"Error al conectar con BYD")}finally{w(!1)}}else E("Por favor introduce usuario y contraseña")},[d,f,l,C,$]),fe=o.useCallback(async()=>{if(r){w(!0),E(null);try{await Ie(r),u(null),N([]),s(!1),B(null),localStorage.removeItem("byd_connected_vin"),localStorage.removeItem("byd_connected_vehicles"),localStorage.removeItem("byd_auto_register_charges"),I("Desconectado correctamente"),U.current?.(!1)}catch(c){T.error("BYD disconnect error:",c),E(c instanceof Error?c.message:"Error al desconectar")}finally{w(!1)}}},[r]),se=o.useCallback(async()=>{if(r){w(!0),E(null),B(null);try{const c=await Me(r);c.success?(B(c.dump),A.success(h("settings.debug.dumpSuccess"))):E("Error al obtener dump")}catch(c){T.error("BYD dump error:",c),E(c instanceof Error?c.message:"Error al obtener dump")}finally{w(!1)}}},[r,h]),ve=o.useCallback(()=>{H.current+=1;const c=H.current;R.current&&clearTimeout(R.current),R.current=setTimeout(()=>{H.current=0},Ve),c>=10&&(H.current=0,R.current&&clearTimeout(R.current),se())},[se]);return{isConnected:p,connectedVin:r,connectedVehicles:k,username:d,password:f,countryCode:l,controlPin:C,setUsername:j,setPassword:v,setCountryCode:g,setControlPin:P,isLoading:D,error:S,success:V,autoRegisterCharges:L,setAutoRegisterCharges:_,heartbeatEnabled:ie,setHeartbeatEnabled:X,hasAbrpToken:de,abrpToken:J,setAbrpToken:te,abrpSaving:ce,debugDump:me,clearDebugDump:o.useCallback(()=>B(null),[]),pendingVehicles:xe,selectVehicle:ge,selectVehiclesSilent:be,cancelVehicleSelection:he,handleConnect:pe,handleDisconnect:fe,handleSaveAbrpToken:ue,handleConnectionTap:ve}})(a),{cars:i,addCar:b,updateCar:m}=G(),n=o.useCallback(x=>{x.length!==0&&(x.forEach(({vin:h,target:p,vehicle:s})=>{i.forEach(r=>{r.vin===h&&r.id!==p&&m(r.id,{vin:void 0,connectorType:void 0})}),p==="new"?b({name:s.name||s.model||"BYD",vin:h,type:"ev",isHybrid:!1,connectorType:"pybyd"}):m(p,{vin:h,connectorType:"pybyd"})}),t.selectVehiclesSilent(x[0].vin))},[i,b,m,t]);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"BYD Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),t.isConnected&&t.connectedVin&&e.jsx(dt,{connectedVin:t.connectedVin,connectedVehicles:t.connectedVehicles,isLoading:t.isLoading,autoRegisterCharges:t.autoRegisterCharges,heartbeatEnabled:t.heartbeatEnabled,hasAbrpToken:t.hasAbrpToken,abrpToken:t.abrpToken,abrpSaving:t.abrpSaving,onDisconnect:t.handleDisconnect,onAutoRegisterChange:t.setAutoRegisterCharges,onHeartbeatChange:t.setHeartbeatEnabled,onAbrpTokenChange:t.setAbrpToken,onSaveAbrpToken:t.handleSaveAbrpToken,onConnectionTap:t.handleConnectionTap}),t.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),t.error]}),t.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),t.success]}),!t.isConnected&&e.jsx(ot,{username:t.username,password:t.password,countryCode:t.countryCode,controlPin:t.controlPin,isLoading:t.isLoading,onUsernameChange:t.setUsername,onPasswordChange:t.setPassword,onCountryCodeChange:t.setCountryCode,onControlPinChange:t.setControlPin,onConnect:t.handleConnect}),t.isConnected&&t.connectedVin&&t.debugDump&&e.jsx(ct,{connectedVin:t.connectedVin,debugDump:t.debugDump,onClose:t.clearDebugDump})]}),t.pendingVehicles&&e.jsx(et,{vehicles:t.pendingVehicles,existingCars:i.map(x=>({id:x.id,name:x.name,vin:x.vin})),onConfirm:n,onCancel:t.cancelVehicleSelection}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},xt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),ut=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),gt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),bt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),ht=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),pt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),ft=()=>{const{t:a,i18n:t}=F(),{settings:i,updateSettings:b}=q(),m=o.useCallback(n=>{t.changeLanguage(n),Le(n)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"flex flex-wrap gap-2",children:Be.map(n=>e.jsxs("button",{role:"radio","aria-checked":t.language===n.code||t.language?.startsWith(n.code),onClick:()=>m(n.code),className:"py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 border "+(t.language===n.code||t.language?.startsWith(n.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"20px",height:"15px"},children:n.code==="gl"?e.jsx(xt,{className:"w-full h-full rounded-sm"}):n.code==="ca"?e.jsx(ut,{className:"w-full h-full rounded-sm"}):n.code==="eu"?e.jsx(gt,{className:"w-full h-full rounded-sm"}):n.code==="es"?e.jsx(bt,{className:"w-full h-full rounded-sm"}):n.code==="en"?e.jsx(ht,{className:"w-full h-full rounded-sm"}):n.code==="pt"?e.jsx(pt,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:n.flag})}),n.name]},n.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(n=>e.jsx("button",{role:"radio","aria-checked":i?.theme===n,onClick:()=>b({...i,theme:n}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(i?.theme===n?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(n==="auto"?"settings.themeAuto":n==="light"?"settings.themeLight":"settings.themeDark")},n))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:We.filter(n=>n!=="overview").map(n=>{const x=(i.hiddenTabs||[]).includes(n);return e.jsxs("button",{onClick:()=>{const h=i.hiddenTabs||[],p=x?h.filter(s=>s!==n):[...h,n];b({...i,hiddenTabs:p})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(x?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${n}`)}),x?e.jsx(Ue,{className:"w-4 h-4"}):e.jsx(He,{className:"w-4 h-4"})]},n)})})]})]})]})},Pt=({onClose:a})=>{const{t}=F(),{googleSync:i,closeModal:b}=Y(),{cars:m,activeCarId:n,updateCar:x,addCar:h,setActiveCarId:p}=G(),{isNative:s}=$e(),r=()=>{a?a():b("settings")};return e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(Oe,{title:t("settings.title"),onClose:r}),e.jsxs("div",{className:"space-y-6 mt-4",children:[e.jsx(st,{}),e.jsx(rt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(nt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(ft,{}),e.jsx(tt,{googleSync:i}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),s&&e.jsx(e.Fragment,{children:e.jsx(mt,{onConnectionChange:(u,k)=>{if(!u){const j=m.find(f=>f.connectorType==="pybyd");return void(j&&x(j.id,{vin:void 0,connectorType:void 0}))}if(!k)return;const N=m.find(j=>j.vin===k);if(N)return n!==N.id&&p(N.id),N.connectorType!=="pybyd"&&x(N.id,{connectorType:"pybyd"}),void m.forEach(j=>{j.id!==N.id&&j.vin===k&&x(j.id,{vin:void 0,connectorType:void 0})});const d=n?m.find(j=>j.id===n):void 0;d&&!d.vin?x(d.id,{vin:k,connectorType:"pybyd"}):h({name:"BYD",vin:k,type:"ev",isHybrid:!1,connectorType:"pybyd"})}})})]}),e.jsx("button",{onClick:r,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:Z},children:t("common.save")})]})})};export{Pt as default};
