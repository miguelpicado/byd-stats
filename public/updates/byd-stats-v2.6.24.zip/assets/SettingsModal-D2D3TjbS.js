const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./MfgDateModal-DC3o4mNB.js","./vendor-react-BpBHRb8g.js","./vendor-i18n-sZC3GtoX.js","./vendor-capacitor-CnICfPQy.js","./vendor-firebase-C8R0NUg4.js","./vendor-charts-B2MWdnDF.js","./index-DDGRXpDB.js","./index-Du-TBrCJ.css","./AbrpHelpModal-BwDGuzIn.js","./BaseModal-CHlHYVLQ.js"])))=>i.map(i=>d[i]);
import{u as C,R as F,j as e,r as c,z as D}from"./vendor-react-BpBHRb8g.js";import{f as $,e as ve,L as ye,R as je,D as Ne,h as we,l as T,w as ae,i as U,j as Y,k as O,m as Ce,n as Se,o as Pe,p as Ee,q as K,Z as Te,T as Fe,r as De,s as Ae,t as ze,v as Me,x as _e,y as Ve,z as Le,E as Be,G as Ie,I as Re,J as He,M as We}from"./index-DDGRXpDB.js";import{_ as se}from"./vendor-capacitor-CnICfPQy.js";import{Y as Ue,U as $e,X as Ye,a2 as Oe,a7 as q,ae as re,af as Ge}from"./vendor-firebase-C8R0NUg4.js";import{i as Je}from"./batteryCalculations-BaqeSYWG.js";import{B as Ke}from"./BydVehiclePickerModal-9rS3Nb34.js";import"./vendor-i18n-sZC3GtoX.js";import"./vendor-charts-B2MWdnDF.js";const qe=({googleSync:a})=>{const{t}=C(),{openModal:i,exportSyncData:b}=$(),[x,l]=F.useState(!1),[m,h]=F.useState(!1);F.useEffect(()=>{l(!1)},[a.userProfile?.imageUrl]);const p=a.userProfile?.imageUrl,s=p&&!x;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(ve,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[s?e.jsx("img",{src:p,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>l(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"}),e.jsx("span",{className:"text-[10px] font-medium text-green-600 dark:text-green-400",children:t("settings.connected")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(ye,{className:"w-5 h-5"})})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(je,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>i("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(Ne,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{h(!0);try{await b()}catch(n){T.error("Export failed:",n)}finally{h(!1)}},disabled:m,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(m?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[m?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(we,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),m?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},Ze=F.lazy(()=>se(()=>import("./MfgDateModal-DC3o4mNB.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)),Xe=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=Y(),{activeCar:b,updateCar:x,activeCarId:l,cars:m}=O(),{stats:h,aiSoH:p}=$(),[s,n]=c.useState(!1),{vehicles:g,loading:k}=(function(){const[r,o]=c.useState([]),[j,N]=c.useState(!0);return c.useEffect(()=>{let A=null,z=!1;return(async()=>{const V=await ae();if(z||!V)return void N(!1);const S=Ue(Ye(U,"bydVehicles"),$e("userId","==",V));A=Oe(S,M=>{const w=[];M.forEach(L=>{const P=L.data();w.push({vin:L.id,modelName:P.modelName,vehicleType:P.vehicleType,lastSoC:P.lastSoC})}),o(w),N(!1)},M=>{T.warn("[useUserVehicles] snapshot error:",M),N(!1)})})(),()=>{z=!0,A?.()}},[]),{vehicles:r,loading:j}})(),y=c.useMemo(()=>{const r=new Map;return g.forEach(o=>{r.set(o.vin,{vin:o.vin,label:o.modelName?`${o.modelName} · ${o.vin}`:o.vin})}),b?.vin&&!r.has(b.vin)&&r.set(b.vin,{vin:b.vin,label:b.vin}),Array.from(r.values())},[g,b?.vin]),u=h?.summary?.sohData,f=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:r=>i({...t,carModel:r.target.value,carColor:void 0}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),Ce.map(({model:r})=>e.jsx("option",{value:r,children:r},r))]}),(()=>{const r=Se(t?.carModel);return r?e.jsxs("div",{className:"mt-3",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carColor","Color del coche")}),e.jsx("div",{className:"flex flex-wrap gap-3",children:r.colors.map(o=>e.jsx("button",{onClick:()=>i({...t,carColor:o.id}),className:"w-8 h-8 rounded-full border-2 transition-all cursor-pointer shadow-sm "+(t?.carColor===o.id?"border-red-500 scale-110 shadow-md ring-2 ring-red-500/20":"border-slate-200 dark:border-slate-600 hover:scale-105"),style:{backgroundColor:o.hex},title:o.name,type:"button","aria-label":`Seleccionar color ${o.name}`},o.id))})]}):null})()]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:b?.name||t?.carName||"",onChange:r=>{const o=r.target.value;i({...t,carName:o}),l&&x(l,{name:o})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carVin",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.vin","VIN asociado")}),e.jsxs("select",{id:"carVin",name:"carVin",value:b?.vin||"",onChange:r=>(o=>{if(!l)return;const j=o||void 0;j&&m.forEach(N=>{N.id!==l&&N.vin===j&&x(N.id,{vin:void 0,connectorType:void 0})}),x(l,{vin:j,connectorType:j?"pybyd":void 0})})(r.target.value),disabled:!l||k&&y.length===0,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 font-mono text-sm disabled:opacity-50",children:[e.jsx("option",{value:"",children:a("settings.vinNone","Sin VIN asociado")}),y.map(r=>e.jsx("option",{value:r.vin,children:r.label},r.vin))]}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.vinHint","Elige qué vehículo BYD real está vinculado a este coche de la app. Si no aparece, conéctate a BYD Direct primero.")})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:r=>i({...t,licensePlate:r.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:r=>i({...t,batterySize:parseFloat(r.target.value)||0}),onBlur:async()=>{if(b?.vin)try{const r=q(U,"bydVehicles",b.vin),o=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!o||o<=0)return;await re(r,{batteryCapacity:o,lastBatteryCapacity:o})}catch(r){T.error("Error syncing battery capacity:",r)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(r=>e.jsx("button",{role:"radio","aria-checked":f===r,onClick:()=>{r!=="calculated"||t.mfgDate||n(!0),i({...t,sohMode:r})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(f===r?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:r==="ai"?"SoH IA":a(`settings.soh${r.charAt(0).toUpperCase()+r.slice(1)}`)},r))}),f==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:r=>i({...t,soh:parseInt(r.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>n(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Pe,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):f==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[u?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[p?.toFixed(1)||100,"%"]})]})})]}),e.jsx(F.Suspense,{fallback:null,children:s&&e.jsx(Ze,{isOpen:s,onClose:()=>n(!1),onSave:(r,o)=>{i({...t,mfgDate:r,mfgDateDisplay:o})},initialValue:t.mfgDateDisplay})})]})},Qe=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=Y(),{activeCar:b}=O(),{charges:x}=(function(){const{charges:s}=$();return{charges:s}})(),{avgElectricPrice:l,avgFuelPrice:m,electricStats:h,fuelStats:p}=c.useMemo(()=>{if(!x||x.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const s=x.filter(r=>!r.type||r.type==="electric"),n=x.filter(r=>r.type==="fuel"),g=s.reduce((r,o)=>r+(o.totalCost||0),0),k=s.reduce((r,o)=>r+(o.kwhCharged||0),0),y=k>0?g/k:0,u=n.reduce((r,o)=>r+(o.totalCost||0),0),f=n.reduce((r,o)=>r+(o.litersCharged||0),0);return{avgElectricPrice:y,avgFuelPrice:f>0?u/f:0,electricStats:{count:s.length,total:g,kwh:k},fuelStats:{count:n.length,total:u,liters:f}}},[x]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const n=t.priceStrategy===s||!t.priceStrategy&&(s==="average"&&t.useCalculatedPrice||s==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>i({...t,priceStrategy:s,useCalculatedPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(n?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s!=="average"||x&&x.length!==0?"":a("settings.priceCalculatedNoData"),children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?l.toFixed(3):t?.electricPrice||0,onChange:s=>i({...t,electricPrice:parseFloat(s.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(h.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:h.count,total:h.total.toFixed(2),kwh:h.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),b?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const n=t.fuelPriceStrategy===s||!t.fuelPriceStrategy&&(s==="average"&&t.useCalculatedFuelPrice||s==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>i({...t,fuelPriceStrategy:s,useCalculatedFuelPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(n?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s==="average"&&p.count===0?a("settings.priceCalculatedNoData"):"",children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?m.toFixed(3):t?.fuelPrice||1.5,onChange:s=>i({...t,fuelPrice:parseFloat(s.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(p.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:p.count,total:p.total.toFixed(2),liters:p.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},et=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=Y(),{charges:b}=Ee(),x=c.useMemo(()=>{const s=t.batterySize,n=typeof s=="string"?parseFloat(s):Number(s);return n>0?n:0},[t.batterySize]),l=c.useMemo(()=>{if(!x||!b?.length)return{};const s={};for(const n of t.chargerTypes??[]){const g=Je(b,x,n.id);g&&(s[n.id]=g)}return s},[b,x,t.chargerTypes]),m=c.useCallback((s,n,g)=>{const k=[...t.chargerTypes||[]];k[s]={...k[s],[n]:g},i({...t,chargerTypes:k})},[t,i]),h=c.useCallback(()=>{const s={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},n=[...t.chargerTypes||[],s];i({...t,chargerTypes:n})},[t,i,a]),p=c.useCallback(s=>{const n=(t.chargerTypes||[]).filter((g,k)=>k!==s);i({...t,chargerTypes:n})},[t,i]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:K},children:e.jsx(Te,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((s,n)=>{const g=`charger_${n}_name`,k=`charger_${n}_speed`,y=`charger_${n}_efficiency`,u=l[s.id],f=s?.efficiency||0,r=u&&Math.abs(u.value-f)>=.01;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:g,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:g,name:g,type:"text",value:s?.name||"",onChange:o=>m(n,"name",o.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),e.jsx("button",{onClick:()=>p(n),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(Fe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:k,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:k,name:k,type:"number",step:"0.1",value:s?.speedKw||0,onChange:o=>m(n,"speedKw",parseFloat(o.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:y,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:y,name:y,type:"number",step:"0.01",min:"0",max:"1",value:s?.efficiency||0,onChange:o=>m(n,"efficiency",parseFloat(o.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),r&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*u.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",u.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>m(n,"efficiency",u.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},s.id)}),e.jsxs("button",{onClick:h,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]}),e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:K},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating||8,onChange:s=>i({...t,homeChargerRating:parseInt(s.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating||8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("label",{id:"offPeakLabel",className:"text-sm text-slate-700 dark:text-slate-300",children:a("settings.offPeakEnabled","Tarifa Valle (Horario Reducido)")}),e.jsx("button",{"aria-labelledby":"offPeakLabel",onClick:()=>{i({...t,offPeakEnabled:!t.offPeakEnabled})},className:"relative inline-flex h-6 w-11 items-center rounded-full transition-colors "+(t.offPeakEnabled?"bg-emerald-500":"bg-slate-300 dark:bg-slate-600"),children:e.jsx("span",{className:"inline-block h-4 w-4 transform rounded-full bg-white transition-transform "+(t.offPeakEnabled?"translate-x-6":"translate-x-1")})})]}),t.offPeakEnabled&&e.jsxs("div",{className:"space-y-3 pl-2 border-l-2 border-slate-200 dark:border-slate-600",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekday","Horario L-V")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStart",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStart",name:"offPeakStart",type:"time",value:t.offPeakStart||"00:00",onChange:s=>i({...t,offPeakStart:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEnd",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEnd",name:"offPeakEnd",type:"time",value:t.offPeakEnd||"08:00",onChange:s=>i({...t,offPeakEnd:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekend","Horario Fin de Semana")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStartWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStartWeekend",name:"offPeakStartWeekend",type:"time",value:t.offPeakStartWeekend||t.offPeakStart||"00:00",onChange:s=>i({...t,offPeakStartWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEndWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEndWeekend",name:"offPeakEndWeekend",type:"time",value:t.offPeakEndWeekend||t.offPeakEnd||"08:00",onChange:s=>i({...t,offPeakEndWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakPrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.offPeakPrice","Precio Valle (€/kWh)")}),e.jsx("input",{id:"offPeakPrice",name:"offPeakPrice",type:"number",step:"0.001",value:t.offPeakPrice||.05,onChange:s=>i({...t,offPeakPrice:parseFloat(s.target.value)||0}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:"0.05"})]})]})]})]})]})},tt=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],at=({username:a,password:t,countryCode:i,controlPin:b,isLoading:x,onUsernameChange:l,onPasswordChange:m,onCountryCodeChange:h,onControlPinChange:p,onConnect:s})=>{const{t:n}=C();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:n("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:g=>l(g.target.value),placeholder:n("settings.emailPlaceholder"),disabled:x})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:n("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:g=>m(g.target.value),placeholder:"••••••••",disabled:x})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:n("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:i,onChange:g=>h(g.target.value),disabled:x,children:tt.map(g=>e.jsx("option",{value:g.code,children:g.name},g.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:n("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:b,onChange:g=>p(g.target.value),placeholder:"1234",maxLength:6,disabled:x}),e.jsx("span",{className:"form-hint",children:"Necesario para bloquear/desbloquear y control de clima"})]}),e.jsx("button",{className:"btn-connect",onClick:s,disabled:x||!a||!t,children:x?"Conectando...":"Conectar con BYD"})]})},st=F.lazy(()=>se(()=>import("./AbrpHelpModal-BwDGuzIn.js"),__vite__mapDeps([8,1,2,3,4,5,9,6,7]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),rt=({connectedVin:a,connectedVehicles:t,isLoading:i,autoRegisterCharges:b,heartbeatEnabled:x,hasAbrpToken:l,abrpToken:m,abrpSaving:h,onDisconnect:p,onAutoRegisterChange:s,onHeartbeatChange:n,onAbrpTokenChange:g,onSaveAbrpToken:k,onConnectionTap:y})=>{const{t:u}=C(),[f,r]=c.useState(!1);return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:y,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),t.length>0&&e.jsx("span",{className:"vehicle-name",children:t[0].name||t[0].model})]})]}),e.jsx("button",{className:"btn-disconnect w-full",onClick:p,disabled:i,children:"Desconectar"}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:u("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:u("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:b,onChange:o=>{const j=o.target.checked;s(j),localStorage.setItem("byd_auto_register_charges",String(j)),D.success(u(j?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:u("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:u("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:x,onChange:o=>(async j=>{n(j);try{await re(q(U,"bydVehicles",a),{heartbeatEnabled:j}),D.success(u(j?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(N){T.error("Error updating heartbeatEnabled:",N),n(!j),D.error(u("errors.genericWithMessage",{message:N.message||u("errors.cannotSave")}))}})(o.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>r(!0),"aria-label":u("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:u("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:m,onChange:o=>g(o.target.value),placeholder:l?u("abrp.tokenPlaceholderSet","Token guardado — escribe uno nuevo para reemplazar"):"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:k,disabled:h,className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:h?"...":u("common.save","Guardar")})]}),l&&!m&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",u("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsx(F.Suspense,{fallback:null,children:f&&e.jsx(st,{isOpen:f,onClose:()=>r(!1)})})]})},nt=({connectedVin:a,debugDump:t,onClose:i})=>{const{t:b}=C();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),D.success(b("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:i,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},lt=({onConnectionChange:a})=>{const t=(m=>{const{t:h}=C(),[p,s]=c.useState(!1),[n,g]=c.useState(null),[k,y]=c.useState([]),[u,f]=c.useState(""),[r,o]=c.useState(""),[j,N]=c.useState("ES"),[A,z]=c.useState(""),[V,S]=c.useState(!1),[M,w]=c.useState(null),[L,P]=c.useState(null),[ne,le]=c.useState(()=>localStorage.getItem("byd_auto_register_charges")==="true"),[oe,Z]=c.useState(!1),[ie,X]=c.useState(!1),[G,Q]=c.useState(""),[de,ee]=c.useState(!1),[ce,B]=c.useState(null),[me,I]=c.useState(null),R=c.useRef(0),_=c.useRef(null),H=c.useRef(m);H.current=m,c.useEffect(()=>{const d=localStorage.getItem("byd_connected_vin"),v=localStorage.getItem("byd_connected_vehicles");if(d&&(g(d),s(!0),H.current?.(!0,d)),v)try{y(JSON.parse(v))}catch{}},[]),c.useEffect(()=>{n&&Ge(q(U,"bydVehicles",n)).then(d=>{d.exists()&&(Z(d.data().heartbeatEnabled===!0),X(d.data().hasAbrpToken===!0))}).catch(()=>{})},[n]);const xe=c.useCallback(async()=>{if(n){ee(!0);try{const d=G.trim();await De(n,d),X(!!d),Q(""),D.success(h(d?"settings.abrp.tokenSaved":"settings.abrp.tokenRemoved"))}catch(d){T.error("Error saving ABRP token:",d),D.error(h("settings.abrp.tokenError"))}finally{ee(!1)}}},[n,G,h]),W=c.useCallback((d,v)=>{g(d),y(v),s(!0),localStorage.setItem("byd_connected_vin",d),localStorage.setItem("byd_connected_vehicles",JSON.stringify(v));const E=v.find(J=>J.vin===d);P(`Conectado: ${E?.name||E?.model||d}`),o(""),z(""),H.current?.(!0,d)},[]),ge=c.useCallback(d=>{I(v=>v&&v.find(E=>E.vin===d)?(W(d,v),null):v)},[W]),ue=c.useCallback(d=>{I(v=>{if(!v)return v;const E=v.find(ke=>ke.vin===d);if(!E)return v;g(d),y(v),s(!0),localStorage.setItem("byd_connected_vin",d),localStorage.setItem("byd_connected_vehicles",JSON.stringify(v));const J=E.name||E.model||d;return P(`Conectado: ${J}`),o(""),z(""),null})},[]),be=c.useCallback(()=>{I(null)},[]),he=c.useCallback(async()=>{if(u&&r){S(!0),w(null),P(null);try{const d=await ae()||"dev-user",v=await Ae(u,r,j,A||void 0,d);v.success&&v.vehicles.length>0?v.vehicles.length===1?W(v.vehicles[0].vin,v.vehicles):I(v.vehicles):w("No se encontraron vehículos en la cuenta")}catch(d){T.error("BYD connect error:",d),w(d instanceof Error?d.message:"Error al conectar con BYD")}finally{S(!1)}}else w("Por favor introduce usuario y contraseña")},[u,r,j,A,W]),pe=c.useCallback(async()=>{if(n){S(!0),w(null);try{await ze(n),g(null),y([]),s(!1),B(null),localStorage.removeItem("byd_connected_vin"),localStorage.removeItem("byd_connected_vehicles"),localStorage.removeItem("byd_auto_register_charges"),P("Desconectado correctamente"),H.current?.(!1)}catch(d){T.error("BYD disconnect error:",d),w(d instanceof Error?d.message:"Error al desconectar")}finally{S(!1)}}},[n]),te=c.useCallback(async()=>{if(n){S(!0),w(null),B(null);try{const d=await Me(n);d.success?(B(d.dump),D.success(h("settings.debug.dumpSuccess"))):w("Error al obtener dump")}catch(d){T.error("BYD dump error:",d),w(d instanceof Error?d.message:"Error al obtener dump")}finally{S(!1)}}},[n,h]),fe=c.useCallback(()=>{R.current+=1;const d=R.current;_.current&&clearTimeout(_.current),_.current=setTimeout(()=>{R.current=0},_e),d>=10&&(R.current=0,_.current&&clearTimeout(_.current),te())},[te]);return{isConnected:p,connectedVin:n,connectedVehicles:k,username:u,password:r,countryCode:j,controlPin:A,setUsername:f,setPassword:o,setCountryCode:N,setControlPin:z,isLoading:V,error:M,success:L,autoRegisterCharges:ne,setAutoRegisterCharges:le,heartbeatEnabled:oe,setHeartbeatEnabled:Z,hasAbrpToken:ie,abrpToken:G,setAbrpToken:Q,abrpSaving:de,debugDump:ce,clearDebugDump:c.useCallback(()=>B(null),[]),pendingVehicles:me,selectVehicle:ge,selectVehiclesSilent:ue,cancelVehicleSelection:be,handleConnect:he,handleDisconnect:pe,handleSaveAbrpToken:xe,handleConnectionTap:fe}})(a),{cars:i,addCar:b,updateCar:x}=O(),l=c.useCallback(m=>{m.length!==0&&(m.forEach(({vin:h,target:p,vehicle:s})=>{i.forEach(n=>{n.vin===h&&n.id!==p&&x(n.id,{vin:void 0,connectorType:void 0})}),p==="new"?b({name:s.name||s.model||"BYD",vin:h,type:"ev",isHybrid:!1,connectorType:"pybyd"}):x(p,{vin:h,connectorType:"pybyd"})}),t.selectVehiclesSilent(m[0].vin))},[i,b,x,t]);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"BYD Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),t.isConnected&&t.connectedVin&&e.jsx(rt,{connectedVin:t.connectedVin,connectedVehicles:t.connectedVehicles,isLoading:t.isLoading,autoRegisterCharges:t.autoRegisterCharges,heartbeatEnabled:t.heartbeatEnabled,hasAbrpToken:t.hasAbrpToken,abrpToken:t.abrpToken,abrpSaving:t.abrpSaving,onDisconnect:t.handleDisconnect,onAutoRegisterChange:t.setAutoRegisterCharges,onHeartbeatChange:t.setHeartbeatEnabled,onAbrpTokenChange:t.setAbrpToken,onSaveAbrpToken:t.handleSaveAbrpToken,onConnectionTap:t.handleConnectionTap}),t.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),t.error]}),t.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),t.success]}),!t.isConnected&&e.jsx(at,{username:t.username,password:t.password,countryCode:t.countryCode,controlPin:t.controlPin,isLoading:t.isLoading,onUsernameChange:t.setUsername,onPasswordChange:t.setPassword,onCountryCodeChange:t.setCountryCode,onControlPinChange:t.setControlPin,onConnect:t.handleConnect}),t.isConnected&&t.connectedVin&&t.debugDump&&e.jsx(nt,{connectedVin:t.connectedVin,debugDump:t.debugDump,onClose:t.clearDebugDump})]}),t.pendingVehicles&&e.jsx(Ke,{vehicles:t.pendingVehicles,existingCars:i.map(m=>({id:m.id,name:m.name,vin:m.vin})),onConfirm:l,onCancel:t.cancelVehicleSelection}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},ot=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),it=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),dt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),ct=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),mt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),xt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),gt=()=>{const{t:a,i18n:t}=C(),{settings:i,updateSettings:b}=Y(),x=c.useCallback(l=>{t.changeLanguage(l),Ve(l)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"flex flex-wrap gap-2",children:Le.map(l=>e.jsxs("button",{role:"radio","aria-checked":t.language===l.code||t.language?.startsWith(l.code),onClick:()=>x(l.code),className:"py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 border "+(t.language===l.code||t.language?.startsWith(l.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"20px",height:"15px"},children:l.code==="gl"?e.jsx(ot,{className:"w-full h-full rounded-sm"}):l.code==="ca"?e.jsx(it,{className:"w-full h-full rounded-sm"}):l.code==="eu"?e.jsx(dt,{className:"w-full h-full rounded-sm"}):l.code==="es"?e.jsx(ct,{className:"w-full h-full rounded-sm"}):l.code==="en"?e.jsx(mt,{className:"w-full h-full rounded-sm"}):l.code==="pt"?e.jsx(xt,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:l.flag})}),l.name]},l.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(l=>e.jsx("button",{role:"radio","aria-checked":i?.theme===l,onClick:()=>b({...i,theme:l}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(i?.theme===l?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(l==="auto"?"settings.themeAuto":l==="light"?"settings.themeLight":"settings.themeDark")},l))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:Be.filter(l=>l!=="overview").map(l=>{const m=(i.hiddenTabs||[]).includes(l);return e.jsxs("button",{onClick:()=>{const h=i.hiddenTabs||[],p=m?h.filter(s=>s!==l):[...h,l];b({...i,hiddenTabs:p})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(m?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${l}`)}),m?e.jsx(Re,{className:"w-4 h-4"}):e.jsx(Ie,{className:"w-4 h-4"})]},l)})})]})]})]})},jt=({onClose:a})=>{const{t}=C(),{googleSync:i,closeModal:b}=$(),{cars:x,activeCarId:l,updateCar:m,addCar:h,setActiveCarId:p}=O(),{isNative:s}=He(),n=()=>{a?a():b("settings")};return e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(We,{title:t("settings.title"),onClose:n}),e.jsxs("div",{className:"space-y-6 mt-4",children:[e.jsx(Xe,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Qe,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(et,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(gt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(qe,{googleSync:i}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),s&&e.jsx(e.Fragment,{children:e.jsx(lt,{onConnectionChange:(g,k)=>{if(!g){const f=x.find(r=>r.connectorType==="pybyd");return void(f&&m(f.id,{vin:void 0,connectorType:void 0}))}if(!k)return;const y=x.find(f=>f.vin===k);if(y)return l!==y.id&&p(y.id),y.connectorType!=="pybyd"&&m(y.id,{connectorType:"pybyd"}),void x.forEach(f=>{f.id!==y.id&&f.vin===k&&m(f.id,{vin:void 0,connectorType:void 0})});const u=l?x.find(f=>f.id===l):void 0;u&&!u.vin?m(u.id,{vin:k,connectorType:"pybyd"}):h({name:"BYD",vin:k,type:"ev",isHybrid:!1,connectorType:"pybyd"})}})})]}),e.jsx("button",{onClick:n,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:K},children:t("common.save")})]})})};export{jt as default};
