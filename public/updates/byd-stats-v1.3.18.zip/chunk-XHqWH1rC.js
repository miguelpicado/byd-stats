import{c as o}from"./assets/index-CvOrqy6e.js";const s=o("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{s as C};
