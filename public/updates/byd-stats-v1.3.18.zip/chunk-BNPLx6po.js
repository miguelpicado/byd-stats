const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./chunk-a1V4ExyU.js","./chunk-DvmHlySd.js","./chunk-BmCUMP0y.js","./chunk-CXYaEaoG.js","./chunk--PZDUsnw.js","./chunk-Daer3YHK.js","./chunk-Ccoi7is-.js","./assets/vendor-leaflet-Dgihpmma.css","./assets/index-CvOrqy6e.js","./assets/index-DAdI7aaF.css","./chunk-BnHpN-F9.js","./chunk-Cr9FSxjk.js","./chunk-C6HOpvvH.js","./chunk-CJZCuCw5.js","./chunk-Bwq1nb67.js","./chunk-DEa8iJbZ.js","./chunk-B2d6f8Sm.js"])))=>i.map(i=>d[i]);
import{u as C,R as D,j as e,r as f,n as R,z as A}from"./chunk-DvmHlySd.js";import{c as U,n as G,k as O,l as T,o as z,d as V,p as ee,g as te,q as ae,r as _,s as $,j as L,Z as se,D as re,t as le,v as ne,w as ie,x as oe,y as ce,z as de,A as xe,G as me,T as he,u as ge}from"./assets/index-CvOrqy6e.js";import{M as q}from"./chunk-Dn_FYN1V.js";import{C as be}from"./chunk-DSQfgQn0.js";import{L as ue}from"./chunk-B9nlGAaP.js";import{R as pe}from"./chunk-G4IUELn0.js";import{D as fe}from"./chunk-D12MXwkV.js";import{D as ve}from"./chunk-0fR7xTot.js";import{_ as H,C as ke,r as je}from"./chunk-CXYaEaoG.js";import{S as ye,Q as Ne,a9 as I,ac as Y,ah as K,ai as Z,a8 as J,ab as Q}from"./chunk--PZDUsnw.js";import{C as we,g as Ce}from"./chunk-DkypVcIh.js";import{i as Se}from"./chunk-BaqeSYWG.js";import{T as Pe}from"./chunk-BEnoEDzR.js";import{u as De}from"./chunk-Bdo1EWVe.js";import{B as Ae}from"./chunk-MIO92QDZ.js";import{E as Fe}from"./chunk-D0N6nLhJ.js";import"./chunk-BmCUMP0y.js";import"./chunk-Daer3YHK.js";import"./chunk-Ccoi7is-.js";import"./chunk-Cy2Xn3ow.js";import"./chunk-Cr9FSxjk.js";const Te=U("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]),ze=U("shield-alert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),Ee=({googleSync:a})=>{const{t}=C(),{openModal:i}=G(),{exportSyncData:d}=O(),[c,m]=D.useState(!1),[r,u]=D.useState(!1);D.useEffect(()=>{m(!1)},[a.userProfile?.imageUrl]);const g=a.userProfile?.imageUrl,l=g&&!c;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(be,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[l?e.jsx("img",{src:g,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>m(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full "+(a.isDriveReady?"bg-green-500 animate-pulse":"bg-amber-400")}),e.jsx("span",{className:"text-[10px] font-medium "+(a.isDriveReady?"text-green-600 dark:text-green-400":"text-amber-600 dark:text-amber-400"),children:a.isDriveReady?t("settings.connected"):t("settings.driveDisconnected","Drive desconectado")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(ue,{className:"w-5 h-5"})})]}),!a.isDriveReady&&e.jsxs("div",{className:"mb-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl",children:[e.jsx("p",{className:"text-xs text-amber-700 dark:text-amber-400 font-medium mb-2",children:t("settings.driveSessionExpired","La sesión de Drive ha expirado")}),e.jsx("button",{onClick:a.login,className:"w-full py-2 px-3 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-all active:scale-[0.98]",children:t("settings.reconnectDrive","Reconectar Google Drive")})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(pe,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>i("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(fe,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{u(!0);try{await d()}catch(o){T.error("Export failed:",o)}finally{u(!1)}},disabled:r,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(r?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[r?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(ve,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),r?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},Me=D.lazy(()=>H(()=>import("./chunk-a1V4ExyU.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13]),import.meta.url)),Be=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z(),{activeCar:d,updateCar:c,activeCarId:m,cars:r}=V(),{vehicles:u,loading:g}=ee(),[l,o]=f.useState(null),b=f.useMemo(()=>{const s=new Map;return u.forEach(n=>{s.set(n.vin,{vin:n.vin,label:n.modelName?`${n.modelName} · ${n.vin}`:n.vin})}),d?.vin&&!s.has(d.vin)&&s.set(d.vin,{vin:d.vin,label:d.vin}),Array.from(s.values())},[u,d?.vin]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:s=>i({...t,carModel:s.target.value,carColor:void 0}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),we.map(({model:s})=>e.jsx("option",{value:s,children:s},s))]}),(()=>{const s=Ce(t?.carModel);return s?e.jsxs("div",{className:"mt-3",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carColor","Color del coche")}),e.jsx("div",{className:"flex flex-wrap gap-3",children:s.colors.map(n=>e.jsx("button",{onClick:()=>i({...t,carColor:n.id}),className:"w-8 h-8 rounded-full border-2 transition-all cursor-pointer shadow-sm "+(t?.carColor===n.id?"border-red-500 scale-110 shadow-md ring-2 ring-red-500/20":"border-slate-200 dark:border-slate-600 hover:scale-105"),style:{backgroundColor:n.hex},title:n.name,type:"button","aria-label":`Seleccionar color ${n.name}`},n.id))})]}):null})()]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:d?.name||t?.carName||"",onChange:s=>{const n=s.target.value;i({...t,carName:n}),m&&c(m,{name:n})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carVin",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.vin","VIN asociado")}),e.jsxs("select",{id:"carVin",name:"carVin",value:d?.vin||"",onChange:s=>(n=>{if(!m)return;const h=n||void 0;h&&r.forEach(x=>{x.id!==m&&x.vin===h&&c(x.id,{vin:void 0,connectorType:void 0})}),c(m,{vin:h,connectorType:h?"pybyd":void 0})})(s.target.value),disabled:!m||g&&b.length===0,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 font-mono text-sm disabled:opacity-50",children:[e.jsx("option",{value:"",children:a("settings.vinNone","Sin VIN asociado")}),b.map(s=>e.jsx("option",{value:s.vin,children:s.label},s.vin))]}),u.length>1&&e.jsxs("div",{className:"mt-4",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.otherVehicles","Otros vehículos en tu cuenta")}),e.jsx("div",{className:"space-y-2",children:u.filter(s=>s.vin!==d?.vin).map(s=>e.jsxs("div",{className:"flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700",children:[e.jsx("span",{className:"text-sm font-mono text-slate-700 dark:text-slate-300",children:s.vin}),e.jsx("button",{type:"button",disabled:l===s.vin,onClick:()=>(async n=>{if(confirm(`¿Estás seguro de que quieres desvincular y borrar de la nube el vehículo ${n}? Esta acción eliminará permanentemente su historial si no hiciste copia en Drive.`)){o(n);try{const h=ye(void 0,"europe-west1");await Ne(h,"bydDetachVehicleV2")({vin:n}),R.success(a("settings.vehicleDetached","Vehículo desvinculado correctamente")),d?.vin===n&&m&&c(m,{vin:void 0,connectorType:void 0})}catch(h){T.error("Error detaching vehicle:",h),R.error(h?.message||"Error al desvincular el vehículo")}finally{o(null)}}})(s.vin),className:"text-xs font-medium text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 disabled:opacity-50",children:l===s.vin?a("common.loading","Cargando..."):a("settings.detachVehicle","Desasociar de mi cuenta")})]},s.vin))})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:s=>i({...t,licensePlate:s.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:s=>i({...t,batterySize:parseFloat(s.target.value)||0}),onBlur:async()=>{if(d?.vin)try{const s=I(_,"bydVehicles",d.vin),n=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!n||n<=0)return;await Y(s,{batteryCapacity:n,lastBatteryCapacity:n})}catch(s){T.error("Error syncing battery capacity:",s)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]})]})},Le=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z(),{stats:d,aiSoH:c}=te(),[m,r]=f.useState(!1),u=d?.summary?.sohData,g=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(l=>e.jsx("button",{role:"radio","aria-checked":g===l,onClick:()=>{l!=="calculated"||t.mfgDate||r(!0),i({...t,sohMode:l})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(g===l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:l==="ai"?"SoH IA":a(`settings.soh${l.charAt(0).toUpperCase()+l.slice(1)}`)},l))}),g==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:l=>i({...t,soh:parseInt(l.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>r(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(ae,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):g==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[u?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[c?.toFixed(1)||100,"%"]})]})})]}),e.jsx(D.Suspense,{fallback:null,children:m&&e.jsx(Me,{isOpen:m,onClose:()=>r(!1),onSave:(l,o)=>{i({...t,mfgDate:l,mfgDateDisplay:o})},initialValue:t.mfgDateDisplay})})]})},Ve=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z(),{activeCar:d}=V(),{charges:c}=(function(){const{charges:l}=$();return{charges:l}})(),{avgElectricPrice:m,avgFuelPrice:r,electricStats:u,fuelStats:g}=f.useMemo(()=>{if(!c||c.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const l=c.filter(k=>!k.type||k.type==="electric"),o=c.filter(k=>k.type==="fuel"),b=l.reduce((k,j)=>k+(j.totalCost||0),0),s=l.reduce((k,j)=>k+(j.kwhCharged||0),0),n=s>0?b/s:0,h=o.reduce((k,j)=>k+(j.totalCost||0),0),x=o.reduce((k,j)=>k+(j.litersCharged||0),0);return{avgElectricPrice:n,avgFuelPrice:x>0?h/x:0,electricStats:{count:l.length,total:b,kwh:s},fuelStats:{count:o.length,total:h,liters:x}}},[c]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(l=>{const o=t.priceStrategy===l||!t.priceStrategy&&(l==="average"&&t.useCalculatedPrice||l==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>i({...t,priceStrategy:l,useCalculatedPrice:l==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(o?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:l!=="average"||c&&c.length!==0?"":a("settings.priceCalculatedNoData"),children:a(l==="custom"?"settings.priceCustom":l==="average"?"settings.priceCalculated":"settings.priceDynamics")},l)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?m.toFixed(3):t?.electricPrice||0,onChange:l=>i({...t,electricPrice:parseFloat(l.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(u.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:u.count,total:u.total.toFixed(2),kwh:u.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),d?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(l=>{const o=t.fuelPriceStrategy===l||!t.fuelPriceStrategy&&(l==="average"&&t.useCalculatedFuelPrice||l==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>i({...t,fuelPriceStrategy:l,useCalculatedFuelPrice:l==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(o?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:l==="average"&&g.count===0?a("settings.priceCalculatedNoData"):"",children:a(l==="custom"?"settings.priceCustom":l==="average"?"settings.priceCalculated":"settings.priceDynamics")},l)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?r.toFixed(3):t?.fuelPrice||1.5,onChange:l=>i({...t,fuelPrice:parseFloat(l.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(g.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:g.count,total:g.total.toFixed(2),liters:g.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},Ie=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z(),{activeCar:d}=V(),c=t.electricityTariff||"flat_24h";f.useEffect(()=>{const r=d?.vin;if(r&&c)try{const u=K(Z());J(I(u,"bydVehicles",r),{electricityTariff:c},{merge:!0})}catch{}},[c,d?.vin]);const m="w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{children:"⚡"}),a("settings.electricityTariff","Tarifa eléctrica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsx("div",{className:"flex gap-1 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["flat_24h","three_period","pvpc"].map(r=>{const u=c===r,g={flat_24h:a("settings.tariff24h","24h"),three_period:a("settings.tariff3periods","3 tramos"),pvpc:a("settings.tariffPVPC","PVPC")};return e.jsx("button",{onClick:()=>{i({...t,electricityTariff:r})},disabled:!1,className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(u?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:g[r]},r)})}),c==="flat_24h"&&e.jsxs("div",{children:[e.jsx("label",{htmlFor:"flatRatePrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.tariff24hPrice","Precio (€/kWh)")}),e.jsx("input",{id:"flatRatePrice",name:"flatRatePrice",type:"number",step:"0.001",value:t.flatRatePrice??.15,onFocus:r=>r.target.select(),onChange:r=>i({...t,flatRatePrice:parseFloat(r.target.value)||0}),className:m,placeholder:"0.15"}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:a("settings.tariff24hDesc","Mismo precio las 24h, todos los días.")})]}),c==="three_period"&&e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"bg-emerald-50 dark:bg-emerald-900/10 rounded-lg p-2.5 border border-emerald-200 dark:border-emerald-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"valleyPrice",className:"text-xs font-semibold text-emerald-700 dark:text-emerald-300",children:a("settings.valleyPrice","Valle")}),e.jsx("span",{className:"text-[10px] text-emerald-600 dark:text-emerald-400",children:a("settings.valleyHours","L-V 0-8h, S-D 24h")})]}),e.jsx("input",{id:"valleyPrice",name:"valleyPrice",type:"number",step:"0.001",value:t.valleyPrice??.08,onFocus:r=>r.target.select(),onChange:r=>i({...t,valleyPrice:parseFloat(r.target.value)||0}),className:m,placeholder:"0.08"})]}),e.jsxs("div",{className:"bg-amber-50 dark:bg-amber-900/10 rounded-lg p-2.5 border border-amber-200 dark:border-amber-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"flatPrice",className:"text-xs font-semibold text-amber-700 dark:text-amber-300",children:a("settings.flatPrice","Llano")}),e.jsx("span",{className:"text-[10px] text-amber-600 dark:text-amber-400",children:a("settings.flatHours","L-V 8-10h, 14-18h, 22-24h")})]}),e.jsx("input",{id:"flatPrice",name:"flatPrice",type:"number",step:"0.001",value:t.flatPrice??.12,onFocus:r=>r.target.select(),onChange:r=>i({...t,flatPrice:parseFloat(r.target.value)||0}),className:m,placeholder:"0.12"})]}),e.jsxs("div",{className:"bg-red-50 dark:bg-red-900/10 rounded-lg p-2.5 border border-red-200 dark:border-red-800/30",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("label",{htmlFor:"peakPrice",className:"text-xs font-semibold text-red-700 dark:text-red-300",children:a("settings.peakPrice","Punta")}),e.jsx("span",{className:"text-[10px] text-red-600 dark:text-red-400",children:a("settings.peakHours","L-V 10-14h, 18-22h")})]}),e.jsx("input",{id:"peakPrice",name:"peakPrice",type:"number",step:"0.001",value:t.peakPrice??.18,onFocus:r=>r.target.select(),onChange:r=>i({...t,peakPrice:parseFloat(r.target.value)||0}),className:m,placeholder:"0.18"})]})]}),c==="pvpc"&&e.jsxs("div",{className:"bg-blue-50 dark:bg-blue-900/10 rounded-lg p-3 border border-blue-200 dark:border-blue-800/30",children:[e.jsx("p",{className:"text-xs text-blue-700 dark:text-blue-300",children:a("settings.pvpcDesc","Precio regulado horario indexado al mercado mayorista (ESIOS). Los precios se obtienen automáticamente al iniciar una carga y se actualizan diariamente.")}),e.jsx("p",{className:"text-[10px] text-blue-500 dark:text-blue-400 mt-2",children:a("settings.pvpcNote","El precio por kWh se calcula según la hora de inicio y duración de cada carga, usando los precios horarios oficiales de REE.")})]})]})]})},Re=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z(),{charges:d}=$(),c=f.useMemo(()=>{const l=t.batterySize,o=typeof l=="string"?parseFloat(l):Number(l);return o>0?o:0},[t.batterySize]),m=f.useMemo(()=>{if(!c||!d?.length)return{};const l={};for(const o of t.chargerTypes??[]){const b=Se(d,c,o.id);b&&(l[o.id]=b)}return l},[d,c,t.chargerTypes]),r=f.useCallback((l,o,b)=>{const s=[...t.chargerTypes||[]];s[l]={...s[l],[o]:b},i({...t,chargerTypes:s})},[t,i]),u=f.useCallback(()=>{const l={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},o=[...t.chargerTypes||[],l];i({...t,chargerTypes:o})},[t,i,a]),g=f.useCallback(l=>{const o=(t.chargerTypes||[]).filter((b,s)=>s!==l);i({...t,chargerTypes:o})},[t,i]);return e.jsx("div",{className:"space-y-4",children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:L},children:e.jsx(se,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((l,o)=>{const b=`charger_${o}_name`,s=`charger_${o}_speed`,n=`charger_${o}_efficiency`,h=m[l.id],x=l?.efficiency||0,k=h&&Math.abs(h.value-x)>=.01,j=l.id===re;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:b,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:b,name:b,type:"text",value:l?.name||"",onChange:p=>r(o,"name",p.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),j?e.jsx("span",{className:"shrink-0 text-[10px] font-semibold px-2 py-1 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",children:"🏠 240V"}):e.jsx("button",{onClick:()=>g(o),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(Pe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:s,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:s,name:s,type:"number",step:"0.1",value:l?.speedKw||0,onChange:p=>r(o,"speedKw",parseFloat(p.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:n,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:n,name:n,type:"number",step:"0.01",min:"0",max:"1",value:l?.efficiency||0,onChange:p=>r(o,"efficiency",parseFloat(p.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),k&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*h.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",h.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>r(o,"efficiency",h.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},l.id)}),e.jsxs("button",{onClick:u,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]})})},_e=()=>{const{t:a}=C(),{settings:t,updateSettings:i}=z();return e.jsx("div",{className:"space-y-4",children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:L},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating??8,onFocus:d=>d.target.select(),onChange:d=>i({...t,homeChargerRating:parseInt(d.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating??8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsx(Ie,{})]})]})})},He=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],We=({username:a,password:t,countryCode:i,controlPin:d,isLoading:c,isActivatingPremium:m=!1,onUsernameChange:r,onPasswordChange:u,onCountryCodeChange:g,onControlPinChange:l,onConnect:o})=>{const{t:b}=C();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:b("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:s=>r(s.target.value),placeholder:b("settings.emailPlaceholder"),disabled:c})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:b("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:s=>u(s.target.value),placeholder:"••••••••",disabled:c})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:b("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:i,onChange:s=>g(s.target.value),disabled:c,children:He.map(s=>e.jsx("option",{value:s.code,children:s.name},s.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:b("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:d,onChange:s=>l(s.target.value),placeholder:"1234",maxLength:6,disabled:c}),e.jsx("span",{className:"form-hint",children:"Opcional. Necesario para algunas funciones avanzadas."})]}),e.jsx("button",{className:"btn-connect",onClick:o,disabled:m||c||!a||!t,children:m?b("settings.activatingPremium"):c?"Conectando...":"Conectar con BYD"})]})},Ue=({connectedVin:a})=>{const{t}=C(),[i,d]=f.useState(100),[c,m]=f.useState(!0),[r,u]=f.useState(!0),[g,l]=f.useState(!1);f.useEffect(()=>{Q(I(_,"bydVehicles",a,"preferences","charging")).then(n=>{if(n.exists()){const h=n.data();typeof h.targetSoc=="number"&&d(h.targetSoc),typeof h.notifyNearTarget=="boolean"&&m(h.notifyNearTarget),typeof h.notifyAtTarget=="boolean"&&u(h.notifyAtTarget)}}).catch(n=>T.warn("[ChargeTargetSettings] Could not read prefs:",n))},[a]);const o=async(n,h,x)=>{l(!0);try{await le(a,n,{notifyNearTarget:h,notifyAtTarget:x}),A.success(t("charging.targetSet","Objetivo de carga actualizado"))}catch(k){T.error("[ChargeTargetSettings] persist error:",k),A.error(t("charging.targetSetError","No se pudo enviar al vehículo"))}finally{l(!1)}},b=()=>{o(i,c,r)},s=i>=100;return e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:t("charging.targetSoc","Objetivo de carga")}),e.jsxs("div",{className:"mt-2 flex items-center gap-3",children:[e.jsx("input",{type:"range",min:50,max:100,step:5,value:i,disabled:g,onChange:n=>{d(Number(n.target.value))},onMouseUp:b,onTouchEnd:b,className:"flex-1 accent-emerald-500 disabled:opacity-50","aria-label":t("charging.targetSoc","Objetivo de carga")}),e.jsx("span",{className:"text-sm font-semibold text-slate-700 dark:text-slate-200 min-w-[5rem] text-right",children:i>=100?t("charging.targetFull","Completa (sin avisos)"):`${i}%`})]}),e.jsxs("div",{className:"mt-3 space-y-2 "+(s?"opacity-40 pointer-events-none":""),children:[e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-300",children:t("charging.notifyNearLabel","Avisar cerca del objetivo")}),e.jsx("input",{type:"checkbox",checked:c,onChange:n=>{const h=n.target.checked;m(h),o(i,h,r)},disabled:s||g,className:"toggle-checkbox w-11 h-6 cursor-pointer"})]}),e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-300",children:t("charging.notifyAtLabel","Avisar al alcanzar el objetivo")}),e.jsx("input",{type:"checkbox",checked:r,onChange:n=>{const h=n.target.checked;u(h),o(i,c,h)},disabled:s||g,className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})]})]})},Ge=D.lazy(()=>H(()=>import("./chunk-Bwq1nb67.js"),__vite__mapDeps([14,1,2,3,4,5,6,7,15,10]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),Oe=D.lazy(()=>H(()=>import("./chunk-B2d6f8Sm.js"),__vite__mapDeps([16,1,2,3,4,5,6,7,15,10]),import.meta.url).then(a=>({default:a.SecondaryAccountModal}))),$e=({connectedVin:a,connectedVehicles:t,isLoading:i,autoRegisterCharges:d,heartbeatEnabled:c,hasAbrpToken:m,abrpToken:r,abrpSaving:u,onDisconnect:g,onRefreshVehicles:l,onAutoRegisterChange:o,onHeartbeatChange:b,onAbrpTokenChange:s,onSaveAbrpToken:n,onConnectionTap:h})=>{const{t:x}=C(),[k,j]=f.useState(!1),[p,y]=f.useState(!1),[v,P]=f.useState(""),[N,E]=f.useState(!1),X=ne(a),M=X?.controlPinStatus;return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:h,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),(()=>{const w=t.find(S=>S.vin===a)??t[0];return w?e.jsx("span",{className:"vehicle-name",children:w.name||w.model}):null})()]})]}),e.jsx("button",{className:"btn-refresh w-full mb-2",onClick:l,disabled:i,children:"Actualizar coches"}),e.jsx("button",{className:"btn-disconnect w-full",onClick:g,disabled:i,children:"Desconectar"}),e.jsxs("button",{onClick:()=>y(!0),className:"mt-3 w-full text-left text-xs text-blue-600 dark:text-blue-400 hover:underline",children:["💡 ",x("secondaryAccount.reminder","Recuerda usar una cuenta secundaria de BYD — toca aquí para ver cómo crearla")]}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:x("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:x("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:d,onChange:w=>{const S=w.target.checked;o(S),localStorage.setItem("byd_auto_register_charges",String(S)),A.success(x(S?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:x("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:x("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:c,onChange:w=>(async S=>{b(S);try{await Y(I(_,"bydVehicles",a),{heartbeatEnabled:S}),A.success(x(S?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(W){T.error("Error updating heartbeatEnabled:",W),b(!S),A.error(x("errors.genericWithMessage",{message:W?.message||x("errors.cannotSave")}))}})(w.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx(Ue,{connectedVin:a}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:x("settings.pin.title","PIN de control")}),M==="set"&&e.jsxs("span",{className:"text-xs font-medium text-green-600 dark:text-green-400",children:["✓ ",x("settings.pin.statusSet","Configurado")]}),M==="invalid"&&e.jsxs("span",{className:"text-xs font-medium text-red-600 dark:text-red-400",children:["✗ ",x("settings.pin.statusInvalid","Incorrecto")]}),(M==="not_set"||M===void 0)&&e.jsx("span",{className:"text-xs font-medium text-amber-600 dark:text-amber-400",children:x("settings.pin.statusNotSet","Sin configurar")})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:x("settings.pin.desc","Necesario para bloquear/desbloquear y controlar el clima. Sin él las acciones rápidas quedan desactivadas.")}),M==="invalid"&&e.jsx("div",{className:"mb-3 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg p-2",children:x("settings.pin.invalidWarning","El PIN guardado es incorrecto. Introdúcelo de nuevo.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:v,onChange:w=>P(w.target.value.replace(/\D/g,"").slice(0,6)),placeholder:M==="set"?x("settings.pin.placeholderChange","Escribe el PIN para cambiarlo"):x("settings.pin.placeholder","Ej. 123456"),inputMode:"numeric",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:async()=>{const w=v.trim();if(w){E(!0);try{await ie(a,w),P(""),A.success(x("settings.pin.saved","PIN de control guardado"))}catch(S){T.error("[BydIntegrationSettings] Error saving PIN:",S),A.error(x("errors.genericWithMessage",{message:S?.message||x("errors.cannotSave")}))}finally{E(!1)}}},disabled:N||!v.trim(),className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:N?"...":x("common.save","Guardar")})]})]}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>j(!0),"aria-label":x("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:x("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:r,onChange:w=>s(w.target.value),placeholder:m?x("abrp.tokenPlaceholderSet","Token guardado — escribe uno nuevo para reemplazar"):"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:n,disabled:u,className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:u?"...":x("common.save","Guardar")})]}),m&&!r&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",x("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsxs(D.Suspense,{fallback:null,children:[k&&e.jsx(Ge,{isOpen:k,onClose:()=>j(!1)}),p&&e.jsx(Oe,{isOpen:p,onClose:()=>y(!1)})]})]})},qe=({connectedVin:a,debugDump:t,onClose:i})=>{const{t:d}=C();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),A.success(d("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:i,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},Ye=({onConnectionChange:a})=>{const{cars:t,activeCar:i,addCar:d,updateCar:c}=V(),m=i?.connectorType==="pybyd"&&i.vin?i.vin:null,r=De(a,m),u=f.useCallback(g=>{g.length!==0&&(g.forEach(({vin:l,target:o,vehicle:b})=>{t.forEach(s=>{s.vin===l&&s.id!==o&&c(s.id,{vin:void 0,connectorType:void 0})}),o==="new"?d({name:b.name||b.model||"BYD",vin:l,type:"ev",isHybrid:!1,connectorType:"pybyd"}):c(o,{vin:l,connectorType:"pybyd"})}),r.selectVehiclesSilent(g[0].vin))},[t,d,c,r]);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),m&&e.jsx($e,{connectedVin:m,connectedVehicles:r.connectedVehicles,isLoading:r.isLoading,autoRegisterCharges:r.autoRegisterCharges,heartbeatEnabled:r.heartbeatEnabled,hasAbrpToken:r.hasAbrpToken,abrpToken:r.abrpToken,abrpSaving:r.abrpSaving,onDisconnect:r.handleDisconnect,onRefreshVehicles:r.handleRefreshVehicles,onAutoRegisterChange:r.setAutoRegisterCharges,onHeartbeatChange:r.setHeartbeatEnabled,onAbrpTokenChange:r.setAbrpToken,onSaveAbrpToken:r.handleSaveAbrpToken,onConnectionTap:r.handleConnectionTap}),r.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),r.error]}),r.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),r.success]}),!m&&e.jsx(We,{username:r.username,password:r.password,countryCode:r.countryCode,controlPin:r.controlPin,isLoading:r.isLoading,isActivatingPremium:r.isActivatingPremium,onUsernameChange:r.setUsername,onPasswordChange:r.setPassword,onCountryCodeChange:r.setCountryCode,onControlPinChange:r.setControlPin,onConnect:r.handleConnect}),m&&r.debugDump&&e.jsx(qe,{connectedVin:m,debugDump:r.debugDump,onClose:r.clearDebugDump})]}),r.pendingVehicles&&e.jsx(Ae,{vehicles:r.pendingVehicles,existingCars:t.map(g=>({id:g.id,name:g.name,vin:g.vin})),onConfirm:u,onCancel:r.cancelVehicleSelection}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect,
                .btn-refresh {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                    text-align: center;
                }

                .btn-refresh {
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    color: #374151;
                }

                .dark .btn-refresh {
                    background: #334155;
                    border: 1px solid #475569;
                    color: #e2e8f0;
                }

                .btn-refresh:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-refresh:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-refresh:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},Ke=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),Ze=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),Je=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),Qe=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),Xe=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),et=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),tt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"213.3",height:"480",fill:"#002395"}),e.jsx("rect",{width:"213.3",height:"480",x:"213.3",fill:"#FFF"}),e.jsx("rect",{width:"213.4",height:"480",x:"426.7",fill:"#ED2939"})]}),at=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"213.3",height:"480",fill:"#009246"}),e.jsx("rect",{width:"213.3",height:"480",x:"213.3",fill:"#FFF"}),e.jsx("rect",{width:"213.4",height:"480",x:"426.7",fill:"#CE2B37"})]}),st=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"160",fill:"#000"}),e.jsx("rect",{width:"640",height:"160",y:"160",fill:"#DD0000"}),e.jsx("rect",{width:"640",height:"160",y:"320",fill:"#FFCE00"})]}),rt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"160",fill:"#AE1C28"}),e.jsx("rect",{width:"640",height:"160",y:"160",fill:"#FFF"}),e.jsx("rect",{width:"640",height:"160",y:"320",fill:"#21468B"})]}),lt=()=>{const{t:a,i18n:t}=C(),{settings:i,updateSettings:d}=z(),c=ke.isNativePlatform(),[m,r]=f.useState(oe),[u,g]=f.useState(()=>localStorage.getItem("wear_complication_action")??"launch_app"),l=f.useCallback(s=>{localStorage.setItem("wear_complication_action",s),g(s)},[]);D.useEffect(()=>{ce(!0)},[]);const o=f.useCallback(s=>{de(s),r(s)},[]),b=f.useCallback(s=>{t.changeLanguage(s),xe(s)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"grid grid-cols-5 gap-2",children:me.map(s=>e.jsxs("button",{role:"radio","aria-checked":t.language===s.code||t.language?.startsWith(s.code),onClick:()=>b(s.code),className:"py-2 rounded-xl text-xs font-semibold transition-colors flex flex-col items-center justify-center gap-1 border "+(t.language===s.code||t.language?.startsWith(s.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),title:s.name,children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"22px",height:"14px"},children:s.code==="gl"?e.jsx(Ke,{className:"w-full h-full rounded-sm"}):s.code==="ca"?e.jsx(Ze,{className:"w-full h-full rounded-sm"}):s.code==="eu"?e.jsx(Je,{className:"w-full h-full rounded-sm"}):s.code==="es"?e.jsx(Qe,{className:"w-full h-full rounded-sm"}):s.code==="en"?e.jsx(Xe,{className:"w-full h-full rounded-sm"}):s.code==="pt"?e.jsx(et,{className:"w-full h-full rounded-sm"}):s.code==="fr"?e.jsx(tt,{className:"w-full h-full rounded-sm"}):s.code==="it"?e.jsx(at,{className:"w-full h-full rounded-sm"}):s.code==="de"?e.jsx(st,{className:"w-full h-full rounded-sm"}):s.code==="nl"?e.jsx(rt,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:s.flag})}),e.jsx("span",{className:"leading-none",children:s.code.toUpperCase()})]},s.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(s=>e.jsx("button",{role:"radio","aria-checked":i?.theme===s,onClick:()=>d({...i,theme:s}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(i?.theme===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(s==="auto"?"settings.themeAuto":s==="light"?"settings.themeLight":"settings.themeDark")},s))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:he.filter(s=>s!=="overview").map(s=>{const n=(i.hiddenTabs||[]).includes(s);return e.jsxs("button",{onClick:()=>{const h=i.hiddenTabs||[],x=n?h.filter(k=>k!==s):[...h,s];d({...i,hiddenTabs:x})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(n?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${s}`)}),n?e.jsx(Fe,{className:"w-4 h-4"}):e.jsx(Te,{className:"w-4 h-4"})]},s)})})]})]}),c&&e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.biometricMode","Método de verificación")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.biometricMode"),className:"flex gap-2",children:[{value:"biometric",label:a("settings.biometricModeHuella","🫆 Biométrico")},{value:"pin",label:a("settings.biometricModePin","🔢 PIN / Patrón")}].map(({value:s,label:n})=>e.jsx("button",{role:"radio","aria-checked":m===s,onClick:()=>o(s),className:"flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-colors border "+(m===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:n},s))}),e.jsx("p",{className:"text-xs text-slate-400 dark:text-slate-500 mt-2",children:m==="biometric"?a("settings.biometricModeHuellaDesc","Usa huella o reconocimiento facial al abrir la app"):a("settings.biometricModePinDesc","Usa el PIN o patrón del teléfono al abrir la app")})]}),c&&e.jsxs("div",{children:[e.jsxs("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:["⌚ ",a("settings.wearComplicationAction","Atajo del reloj")]}),e.jsx("p",{className:"text-xs text-slate-400 dark:text-slate-500 mb-2",children:a("settings.wearComplicationActionDesc","Qué hace el icono de BYD Stats en la esfera del reloj")}),e.jsx("div",{role:"radiogroup","aria-label":"Wear complication action",className:"flex gap-2",children:[{value:"launch_app",label:"📱 "+a("settings.wearActionLaunch","Abrir app")},{value:"unlock_car",label:"🔓 "+a("settings.wearActionUnlock","Abrir coche")}].map(({value:s,label:n})=>e.jsx("button",{role:"radio","aria-checked":u===s,onClick:()=>l(s),className:"flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-colors border "+(u===s?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:n},s))})]})]})},F=je("BluetoothTracker"),nt=()=>{const{t:a}=C(),{activeCarId:t,cars:i}=V(),[d,c]=f.useState([]),[m,r]=f.useState(""),[u,g]=f.useState(!1),[l,o]=f.useState(!1),[b,s]=f.useState(!1),[n,h]=f.useState(!1),x=i.find(p=>p.id===t);f.useEffect(()=>{k()},[t]);const k=async()=>{try{const p=await F.getTargetDevice();p.mac?(r(p.mac),g(!0)):(g(!1),r(""))}catch(p){console.error("Failed to load BT settings",p)}try{const p=await F.getActivityState();s(!!p.enabled)}catch(p){console.error("Failed to load activity settings",p)}},j=async p=>{const y=K(Z()),v=I(y,"bydVehicles",p,"preferences","integration");let N=(await Q(v)).data()?.btSecurityToken;return N||(N=crypto.randomUUID(),await J(v,{btSecurityToken:N},{merge:!0})),N};return x?.vin?e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2",children:[e.jsx("div",{className:"p-2 rounded-xl",style:{backgroundColor:`${L}15`,color:L},children:e.jsx(ze,{className:"w-5 h-5"})}),e.jsx("h3",{className:"text-lg font-semibold text-slate-800 dark:text-white",children:a("settings.security.title","Seguridad y Bluetooth")})]}),e.jsx("p",{className:"text-sm text-slate-600 dark:text-slate-400",children:a("settings.security.btDescription","Al desconectar el Bluetooth del coche, la app intentará avisarte si las puertas o las ventanas se han quedado abiertas.")}),e.jsxs("div",{className:"flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700",children:[e.jsx("div",{className:"flex flex-col",children:e.jsx("span",{className:"font-medium text-slate-800 dark:text-white",children:a("settings.security.btAlerts","Avisos Bluetooth")})}),e.jsxs("label",{className:"relative inline-flex items-center cursor-pointer",children:[e.jsx("input",{type:"checkbox",className:"sr-only peer",checked:u,onChange:p=>(async y=>{if(!y)return await F.setTargetDevice({mac:"",vin:""}),g(!1),void r("");o(!0);try{const v=await F.getPairedDevices();c(v.devices||[]),g(!0)}catch(v){alert(v?.message||"Permiso denegado o Bluetooth no disponible"),g(!1)}finally{o(!1)}})(p.target.checked),disabled:l}),e.jsx("div",{className:"w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"})]})]}),u&&d.length>0&&e.jsxs("div",{className:"p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3",children:[e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-300",children:a("settings.security.selectDevice","Selecciona el Bluetooth del coche:")}),e.jsxs("select",{className:"w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg p-2.5 text-slate-800 dark:text-white",value:m,onChange:p=>(async y=>{if(x?.vin){o(!0);try{const v=x.vin,P=await j(v);await F.setTargetDevice({mac:y,vin:v,token:P}),r(y)}catch(v){console.error(v),alert("Error guardando configuración")}finally{o(!1)}}})(p.target.value),disabled:l,children:[e.jsx("option",{value:"",children:a("common.select","Seleccionar...")}),d.map(p=>e.jsx("option",{value:p.mac,children:p.name||p.mac},p.mac))]})]}),e.jsxs("div",{className:"flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700",children:[e.jsxs("div",{className:"flex flex-col pr-3",children:[e.jsx("span",{className:"font-medium text-slate-800 dark:text-white",children:a("settings.security.activityTitle","Detección automática de viaje")}),e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.security.activityDescription","Intentará iniciar el viaje mucho más rápido aprovechando la conexión Bluetooth y el reconocimiento de actividad. No es imprescindible para detectar los viajes: solo mejora la rapidez de detección.")})]}),e.jsxs("label",{className:"relative inline-flex items-center cursor-pointer",children:[e.jsx("input",{type:"checkbox",className:"sr-only peer",checked:b,onChange:p=>(async y=>{if(y){if(x?.vin){h(!0);try{const v=x.vin,P=await j(v);await F.enableActivityRecognition({vin:v,token:P}),s(!0)}catch(v){alert(v?.message||a("settings.security.activityDenied","Permiso de actividad denegado")),s(!1)}finally{h(!1)}}}else{try{await F.disableActivityRecognition()}catch{}s(!1)}})(p.target.checked),disabled:n}),e.jsx("div",{className:"w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"})]})]})]}):null},B=({title:a,onBack:t,saveLabel:i,children:d})=>e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(q,{title:a,onClose:t}),e.jsx("div",{className:"space-y-6 mt-4",children:d}),e.jsx("button",{onClick:t,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:L},children:i})]})}),Dt=({onClose:a})=>{const{t}=C(),{closeModal:i}=G(),{googleSync:d}=O(),{cars:c,activeCarId:m,updateCar:r,addCar:u,setActiveCarId:g}=V(),{isNative:l}=ge(),[o,b]=f.useState(null),[s,n]=f.useState(!1),[h,x]=f.useState(!1),k=()=>{a?a():i("settings")},j=()=>{b(null)};return o==="byd_api"?e.jsx(B,{title:"Direct API",onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Ye,{onConnectionChange:(p,y)=>{if(!p){const N=y?c.find(E=>E.vin===y):c.find(E=>E.connectorType==="pybyd");return void(N&&r(N.id,{vin:void 0,connectorType:void 0}))}if(!y)return;const v=c.find(N=>N.vin===y);if(v)return m!==v.id&&g(v.id),v.connectorType!=="pybyd"&&r(v.id,{connectorType:"pybyd"}),void c.forEach(N=>{N.id!==v.id&&N.vin===y&&r(N.id,{vin:void 0,connectorType:void 0})});const P=m?c.find(N=>N.id===m):void 0;P&&!P.vin?r(P.id,{vin:y,connectorType:"pybyd"}):u({name:"BYD",vin:y,type:"ev",isHybrid:!1,connectorType:"pybyd"})}})}):o==="sync"?e.jsx(B,{title:t("settings.googleDrive","Nube y Sincronización"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Ee,{googleSync:d})}):o==="car"?e.jsx(B,{title:t("settings.carConfiguration","Configuración del coche"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Be,{})}):o==="chargers"?e.jsx(B,{title:t("settings.chargerTypes","Tipos de cargadores"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(Re,{})}):o==="home_charging"?e.jsx(B,{title:t("settings.homeCharging","Carga Doméstica"),onBack:j,saveLabel:t("common.save","Guardar"),children:e.jsx(_e,{})}):o==="customization"?e.jsxs(B,{title:t("settings.personalization","Personalización"),onBack:j,saveLabel:t("common.save","Guardar"),children:[e.jsx(lt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2",children:t("settings.electricityPrice","Precio electricidad")}),e.jsx(Ve,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Le,{}),l&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(nt,{})]})]}):s?e.jsx("div",{className:"fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-sm shadow-2xl p-6 relative",children:[e.jsx("h3",{className:"text-lg font-bold text-slate-900 dark:text-white mb-2",children:t("settings.deleteAccountConfirmTitle","¿Eliminar tu cuenta?")}),e.jsx("p",{className:"text-sm text-slate-600 dark:text-slate-400 mb-5 leading-relaxed",children:t("settings.deleteAccountConfirmBody","Esta acción es permanente. Se borrarán tu cuenta, la suscripción y la vinculación con tus vehículos. Esta acción no se puede deshacer.")}),e.jsxs("button",{onClick:async()=>{x(!0);try{await d.deleteAccount(),R.success(t("settings.deleteAccountDone","Cuenta eliminada"))}catch(p){const y=p;if(y.message&&/cancel|1001/i.test(y.message))return x(!1),void n(!1);R.error(t("settings.deleteAccountError","No se pudo eliminar la cuenta. Inténtalo de nuevo.")),x(!1),n(!1)}},disabled:h,className:"w-full py-3 rounded-xl font-bold text-white bg-red-600 hover:bg-red-700 transition-all active:scale-[0.98] disabled:opacity-60 flex items-center justify-center gap-2",children:[h&&e.jsx("div",{className:"w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"}),h?t("settings.deleteAccountDeleting","Eliminando..."):t("settings.deleteAccountConfirmCta","Sí, eliminar mi cuenta")]}),e.jsx("button",{onClick:()=>n(!1),disabled:h,className:"w-full mt-2 py-3 rounded-xl font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors disabled:opacity-60",children:t("common.cancel","Cancelar")})]})}):e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(q,{title:t("settings.title","Configuración"),onClose:k}),e.jsxs("div",{className:"space-y-3 mt-4",children:[l&&e.jsxs("button",{onClick:()=>b("byd_api"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"⚡"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:"Direct API"}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descBydApi","Conexión directa con tu vehículo")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("sync"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"☁️"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.googleDrive","Nube y Sincronización")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descCloudSync","Copia de seguridad en Google Drive")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("car"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🚗"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.carConfiguration","Configuración del coche")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descCarConfig","Modelo, VIN, matrícula y batería")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("chargers"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🔌"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.chargerTypes","Tipos de cargadores")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descChargerTypes","Velocidades y eficiencias de carga")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("home_charging"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🏠"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.homeCharging","Carga Doméstica")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descHomeCharging","Potencia y horarios de tarifa valle")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),e.jsxs("button",{onClick:()=>b("customization"),className:"w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/30 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-2xl border border-slate-100 dark:border-slate-700 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🎨"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white group-hover:text-red-500 dark:group-hover:text-red-400 transition-colors",children:t("settings.personalization","Personalización")}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:t("settings.descPersonalization","Idioma, tema, SoH, precios y seguridad")})]})]}),e.jsx("span",{className:"text-slate-400 group-hover:translate-x-1 transition-transform",children:"→"})]}),d.isAuthenticated&&e.jsxs("button",{onClick:()=>n(!0),className:"w-full flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/15 hover:bg-red-100 dark:hover:bg-red-900/25 rounded-2xl border border-red-100 dark:border-red-900/40 transition-all text-left group active:scale-[0.99]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("span",{className:"text-xl",children:"🗑️"}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-red-600 dark:text-red-400",children:t("settings.deleteAccount","Eliminar cuenta")}),e.jsx("p",{className:"text-xs text-red-500/80 dark:text-red-400/70",children:t("settings.deleteAccountDesc","Borra tu cuenta y todos tus datos de forma permanente")})]})]}),e.jsx("span",{className:"text-red-400 group-hover:translate-x-1 transition-transform",children:"→"})]})]}),e.jsx("button",{onClick:k,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:L},children:t("common.close","Cerrar")})]})})};export{Dt as default};
