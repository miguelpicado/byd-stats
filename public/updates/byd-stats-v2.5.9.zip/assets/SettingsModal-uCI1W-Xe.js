const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./MfgDateModal-DvqMtFFD.js","./vendor-react-DxjTY0rd.js","./vendor-i18n-nheEQFic.js","./vendor-capacitor-BixQsqqo.js","./vendor-charts-B2MWdnDF.js","./index-BMGaFkNc.js","./vendor-firebase-C5_cSMAJ.js","./index-DgsrUsUE.css","./AbrpHelpModal-CTX21wQw.js","./BaseModal-C3bcdlJ4.js"])))=>i.map(i=>d[i]);
import{u as j,R as C,j as e,r as i,z as S}from"./vendor-react-DxjTY0rd.js";import{f as M,e as le,L as oe,R as de,D as ie,h as ce,l as w,i as B,j as I,k as xe,m as H,n as me,o as R,Z as ge,T as be,p as ue,w as he,q as pe,r as fe,s as ke,t as ve,v as je,x as ye,E as Ne,y as we,z as Ce,M as Se}from"./index-BMGaFkNc.js";import{_ as G}from"./vendor-capacitor-BixQsqqo.js";import{v as W,y as K,z as Pe}from"./vendor-firebase-C5_cSMAJ.js";import{i as Fe}from"./batteryCalculations-BaqeSYWG.js";import"./vendor-i18n-nheEQFic.js";import"./vendor-charts-B2MWdnDF.js";const De=({googleSync:a})=>{const{t}=j(),{openModal:o,exportSyncData:m}=M(),[g,r]=C.useState(!1),[d,h]=C.useState(!1);C.useEffect(()=>{r(!1)},[a.userProfile?.imageUrl]);const p=a.userProfile?.imageUrl,s=p&&!g;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(le,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[s?e.jsx("img",{src:p,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>r(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"}),e.jsx("span",{className:"text-[10px] font-medium text-green-600 dark:text-green-400",children:t("settings.connected")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(oe,{className:"w-5 h-5"})})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(de,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>o("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(ie,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{h(!0);try{await m()}catch(l){w.error("Export failed:",l)}finally{h(!1)}},disabled:d,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(d?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[d?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(ce,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),d?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},Ee=C.lazy(()=>G(()=>import("./MfgDateModal-DvqMtFFD.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)),Te=()=>{const{t:a}=j(),{settings:t,updateSettings:o}=B(),{activeCar:m,updateCar:g,activeCarId:r}=I(),{stats:d,aiSoH:h}=M(),[p,s]=i.useState(!1),l=d?.summary?.sohData,c=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:n=>o({...t,carModel:n.target.value}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),["BYD Seal","BYD Dolphin","BYD Dolphin Surf","BYD Seal U","BYD Sealion 7","BYD Tang","BYD Atto 2","BYD Atto 3"].map(n=>e.jsx("option",{value:n,children:n},n))]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:m?.name||t?.carName||"",onChange:n=>{const x=n.target.value;o({...t,carName:x}),r&&g(r,{name:x})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:n=>o({...t,licensePlate:n.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:n=>o({...t,batterySize:parseFloat(n.target.value)||0}),onBlur:async()=>{if(m?.vin)try{const n=W(H,"bydVehicles",m.vin),x=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!x||x<=0)return;await K(n,{batteryCapacity:x,lastBatteryCapacity:x})}catch(n){w.error("Error syncing battery capacity:",n)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(n=>e.jsx("button",{role:"radio","aria-checked":c===n,onClick:()=>{n!=="calculated"||t.mfgDate||s(!0),o({...t,sohMode:n})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(c===n?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:n==="ai"?"SoH IA":a(`settings.soh${n.charAt(0).toUpperCase()+n.slice(1)}`)},n))}),c==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:n=>o({...t,soh:parseInt(n.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>s(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(xe,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):c==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[l?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[h?.toFixed(1)||100,"%"]})]})})]}),e.jsx(C.Suspense,{fallback:null,children:p&&e.jsx(Ee,{isOpen:p,onClose:()=>s(!1),onSave:(n,x)=>{o({...t,mfgDate:n,mfgDateDisplay:x})},initialValue:t.mfgDateDisplay})})]})},ze=()=>{const{t:a}=j(),{settings:t,updateSettings:o}=B(),{activeCar:m}=I(),{charges:g}=(function(){const{charges:s}=M();return{charges:s}})(),{avgElectricPrice:r,avgFuelPrice:d,electricStats:h,fuelStats:p}=i.useMemo(()=>{if(!g||g.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const s=g.filter(f=>!f.type||f.type==="electric"),l=g.filter(f=>f.type==="fuel"),c=s.reduce((f,u)=>f+(u.totalCost||0),0),n=s.reduce((f,u)=>f+(u.kwhCharged||0),0),x=n>0?c/n:0,k=l.reduce((f,u)=>f+(u.totalCost||0),0),v=l.reduce((f,u)=>f+(u.litersCharged||0),0);return{avgElectricPrice:x,avgFuelPrice:v>0?k/v:0,electricStats:{count:s.length,total:c,kwh:n},fuelStats:{count:l.length,total:k,liters:v}}},[g]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const l=t.priceStrategy===s||!t.priceStrategy&&(s==="average"&&t.useCalculatedPrice||s==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>o({...t,priceStrategy:s,useCalculatedPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s!=="average"||g&&g.length!==0?"":a("settings.priceCalculatedNoData"),children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?r.toFixed(3):t?.electricPrice||0,onChange:s=>o({...t,electricPrice:parseFloat(s.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(h.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:h.count,total:h.total.toFixed(2),kwh:h.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),m?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const l=t.fuelPriceStrategy===s||!t.fuelPriceStrategy&&(s==="average"&&t.useCalculatedFuelPrice||s==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>o({...t,fuelPriceStrategy:s,useCalculatedFuelPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s==="average"&&p.count===0?a("settings.priceCalculatedNoData"):"",children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?d.toFixed(3):t?.fuelPrice||1.5,onChange:s=>o({...t,fuelPrice:parseFloat(s.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(p.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:p.count,total:p.total.toFixed(2),liters:p.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},Ae=()=>{const{t:a}=j(),{settings:t,updateSettings:o}=B(),{charges:m}=me(),g=i.useMemo(()=>{const s=t.batterySize,l=typeof s=="string"?parseFloat(s):Number(s);return l>0?l:0},[t.batterySize]),r=i.useMemo(()=>{if(!g||!m?.length)return{};const s={};for(const l of t.chargerTypes??[]){const c=Fe(m,g,l.id);c&&(s[l.id]=c)}return s},[m,g,t.chargerTypes]),d=i.useCallback((s,l,c)=>{const n=[...t.chargerTypes||[]];n[s]={...n[s],[l]:c},o({...t,chargerTypes:n})},[t,o]),h=i.useCallback(()=>{const s={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},l=[...t.chargerTypes||[],s];o({...t,chargerTypes:l})},[t,o,a]),p=i.useCallback(s=>{const l=(t.chargerTypes||[]).filter((c,n)=>n!==s);o({...t,chargerTypes:l})},[t,o]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:R},children:e.jsx(ge,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((s,l)=>{const c=`charger_${l}_name`,n=`charger_${l}_speed`,x=`charger_${l}_efficiency`,k=r[s.id],v=s?.efficiency||0,f=k&&Math.abs(k.value-v)>=.01;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:c,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:c,name:c,type:"text",value:s?.name||"",onChange:u=>d(l,"name",u.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),e.jsx("button",{onClick:()=>p(l),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(be,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:n,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:n,name:n,type:"number",step:"0.1",value:s?.speedKw||0,onChange:u=>d(l,"speedKw",parseFloat(u.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:x,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:x,name:x,type:"number",step:"0.01",min:"0",max:"1",value:s?.efficiency||0,onChange:u=>d(l,"efficiency",parseFloat(u.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),f&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*k.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",k.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>d(l,"efficiency",k.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},s.id)}),e.jsxs("button",{onClick:h,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]}),e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:R},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating||8,onChange:s=>o({...t,homeChargerRating:parseInt(s.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating||8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("label",{id:"offPeakLabel",className:"text-sm text-slate-700 dark:text-slate-300",children:a("settings.offPeakEnabled","Tarifa Valle (Horario Reducido)")}),e.jsx("button",{"aria-labelledby":"offPeakLabel",onClick:()=>{o({...t,offPeakEnabled:!t.offPeakEnabled})},className:"relative inline-flex h-6 w-11 items-center rounded-full transition-colors "+(t.offPeakEnabled?"bg-emerald-500":"bg-slate-300 dark:bg-slate-600"),children:e.jsx("span",{className:"inline-block h-4 w-4 transform rounded-full bg-white transition-transform "+(t.offPeakEnabled?"translate-x-6":"translate-x-1")})})]}),t.offPeakEnabled&&e.jsxs("div",{className:"space-y-3 pl-2 border-l-2 border-slate-200 dark:border-slate-600",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekday","Horario L-V")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStart",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStart",name:"offPeakStart",type:"time",value:t.offPeakStart||"00:00",onChange:s=>o({...t,offPeakStart:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEnd",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEnd",name:"offPeakEnd",type:"time",value:t.offPeakEnd||"08:00",onChange:s=>o({...t,offPeakEnd:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekend","Horario Fin de Semana")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStartWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStartWeekend",name:"offPeakStartWeekend",type:"time",value:t.offPeakStartWeekend||t.offPeakStart||"00:00",onChange:s=>o({...t,offPeakStartWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEndWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEndWeekend",name:"offPeakEndWeekend",type:"time",value:t.offPeakEndWeekend||t.offPeakEnd||"08:00",onChange:s=>o({...t,offPeakEndWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakPrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.offPeakPrice","Precio Valle (€/kWh)")}),e.jsx("input",{id:"offPeakPrice",name:"offPeakPrice",type:"number",step:"0.001",value:t.offPeakPrice||.05,onChange:s=>o({...t,offPeakPrice:parseFloat(s.target.value)||0}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:"0.05"})]})]})]})]})]})},Me=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],Be=({username:a,password:t,countryCode:o,controlPin:m,isLoading:g,onUsernameChange:r,onPasswordChange:d,onCountryCodeChange:h,onControlPinChange:p,onConnect:s})=>{const{t:l}=j();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:l("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:c=>r(c.target.value),placeholder:l("settings.emailPlaceholder"),disabled:g})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:l("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:c=>d(c.target.value),placeholder:"••••••••",disabled:g})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:l("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:o,onChange:c=>h(c.target.value),disabled:g,children:Me.map(c=>e.jsx("option",{value:c.code,children:c.name},c.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:l("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:m,onChange:c=>p(c.target.value),placeholder:"1234",maxLength:6,disabled:g}),e.jsx("span",{className:"form-hint",children:"Necesario para bloquear/desbloquear y control de clima"})]}),e.jsx("button",{className:"btn-connect",onClick:s,disabled:g||!a||!t,children:g?"Conectando...":"Conectar con BYD"})]})},Le=C.lazy(()=>G(()=>import("./AbrpHelpModal-CTX21wQw.js"),__vite__mapDeps([8,1,2,3,4,9,5,6,7]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),_e=({connectedVin:a,connectedVehicles:t,isLoading:o,autoRegisterCharges:m,heartbeatEnabled:g,abrpToken:r,abrpSaving:d,onDisconnect:h,onAutoRegisterChange:p,onHeartbeatChange:s,onAbrpTokenChange:l,onSaveAbrpToken:c,onConnectionTap:n})=>{const{t:x}=j(),[k,v]=i.useState(!1);return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:n,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),t.length>0&&e.jsx("span",{className:"vehicle-name",children:t[0].name||t[0].model})]})]}),e.jsx("button",{className:"btn-disconnect w-full",onClick:h,disabled:o,children:"Desconectar"}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:x("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:x("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:m,onChange:f=>{const u=f.target.checked;p(u),localStorage.setItem("byd_auto_register_charges",String(u)),S.success(x(u?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:x("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:x("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:g,onChange:f=>(async u=>{s(u);try{await K(W(H,"bydVehicles",a),{heartbeatEnabled:u}),S.success(x(u?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(D){w.error("Error updating heartbeatEnabled:",D),s(!u),S.error(x("errors.genericWithMessage",{message:D.message||x("errors.cannotSave")}))}})(f.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>v(!0),"aria-label":x("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:x("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{type:"password",value:r,onChange:f=>l(f.target.value),placeholder:"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"flex-1 px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:c,disabled:d,className:"flex-shrink-0 px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:d?"...":x("common.save","Guardar")})]}),r&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",x("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsx(C.Suspense,{fallback:null,children:k&&e.jsx(Le,{isOpen:k,onClose:()=>v(!1)})})]})},Re=({connectedVin:a,debugDump:t,onClose:o})=>{const{t:m}=j();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),S.success(m("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:o,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},Ie=({onConnectionChange:a})=>{const t=(o=>{const{t:m}=j(),[g,r]=i.useState(!1),[d,h]=i.useState(null),[p,s]=i.useState([]),[l,c]=i.useState(""),[n,x]=i.useState(""),[k,v]=i.useState("ES"),[f,u]=i.useState(""),[D,P]=i.useState(!1),[J,y]=i.useState(null),[q,L]=i.useState(null),[Z,Q]=i.useState(()=>localStorage.getItem("byd_auto_register_charges")==="true"),[X,V]=i.useState(!1),[E,Y]=i.useState(""),[ee,U]=i.useState(!1),[te,T]=i.useState(null),z=i.useRef(0),F=i.useRef(null),A=i.useRef(o);A.current=o,i.useEffect(()=>{const b=localStorage.getItem("byd_connected_vin"),N=localStorage.getItem("byd_connected_vehicles");if(b&&(h(b),r(!0),A.current?.(!0,b)),N)try{s(JSON.parse(N))}catch{}},[]),i.useEffect(()=>{d&&Pe(W(H,"bydVehicles",d)).then(b=>{b.exists()&&(V(b.data().heartbeatEnabled===!0),Y(b.data().abrpUserToken||""))}).catch(()=>{})},[d]);const ae=i.useCallback(async()=>{if(d){U(!0);try{await ue(d,E.trim()),S.success(E.trim()?m("settings.abrp.tokenSaved"):m("settings.abrp.tokenRemoved"))}catch(b){w.error("Error saving ABRP token:",b),S.error(m("settings.abrp.tokenError"))}finally{U(!1)}}},[d,E,m]),se=i.useCallback(async()=>{if(l&&n){P(!0),y(null),L(null);try{const b=await he()||"dev-user",N=await pe(l,n,k,f||void 0,b);if(N.success&&N.vehicles.length>0){const _=N.vehicles[0].vin;h(_),s(N.vehicles),r(!0),localStorage.setItem("byd_connected_vin",_),localStorage.setItem("byd_connected_vehicles",JSON.stringify(N.vehicles)),L(`Conectado: ${N.vehicles.map($=>$.name||$.model).join(", ")}`),x(""),u(""),A.current?.(!0,_)}else y("No se encontraron vehículos en la cuenta")}catch(b){w.error("BYD connect error:",b),y(b instanceof Error?b.message:"Error al conectar con BYD")}finally{P(!1)}}else y("Por favor introduce usuario y contraseña")},[l,n,k,f]),re=i.useCallback(async()=>{if(d){P(!0),y(null);try{await fe(d),h(null),s([]),r(!1),T(null),localStorage.removeItem("byd_connected_vin"),localStorage.removeItem("byd_connected_vehicles"),localStorage.removeItem("byd_auto_register_charges"),L("Desconectado correctamente"),A.current?.(!1)}catch(b){w.error("BYD disconnect error:",b),y(b instanceof Error?b.message:"Error al desconectar")}finally{P(!1)}}},[d]),O=i.useCallback(async()=>{if(d){P(!0),y(null),T(null);try{const b=await ke(d);b.success?(T(b.dump),S.success(m("settings.debug.dumpSuccess"))):y("Error al obtener dump")}catch(b){w.error("BYD dump error:",b),y(b instanceof Error?b.message:"Error al obtener dump")}finally{P(!1)}}},[d,m]),ne=i.useCallback(()=>{z.current+=1;const b=z.current;F.current&&clearTimeout(F.current),F.current=setTimeout(()=>{z.current=0},ve),b>=10&&(z.current=0,F.current&&clearTimeout(F.current),O())},[O]);return{isConnected:g,connectedVin:d,connectedVehicles:p,username:l,password:n,countryCode:k,controlPin:f,setUsername:c,setPassword:x,setCountryCode:v,setControlPin:u,isLoading:D,error:J,success:q,autoRegisterCharges:Z,setAutoRegisterCharges:Q,heartbeatEnabled:X,setHeartbeatEnabled:V,abrpToken:E,setAbrpToken:Y,abrpSaving:ee,debugDump:te,clearDebugDump:i.useCallback(()=>T(null),[]),handleConnect:se,handleDisconnect:re,handleSaveAbrpToken:ae,handleConnectionTap:ne}})(a);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"BYD Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),t.isConnected&&t.connectedVin&&e.jsx(_e,{connectedVin:t.connectedVin,connectedVehicles:t.connectedVehicles,isLoading:t.isLoading,autoRegisterCharges:t.autoRegisterCharges,heartbeatEnabled:t.heartbeatEnabled,abrpToken:t.abrpToken,abrpSaving:t.abrpSaving,onDisconnect:t.handleDisconnect,onAutoRegisterChange:t.setAutoRegisterCharges,onHeartbeatChange:t.setHeartbeatEnabled,onAbrpTokenChange:t.setAbrpToken,onSaveAbrpToken:t.handleSaveAbrpToken,onConnectionTap:t.handleConnectionTap}),t.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),t.error]}),t.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),t.success]}),!t.isConnected&&e.jsx(Be,{username:t.username,password:t.password,countryCode:t.countryCode,controlPin:t.controlPin,isLoading:t.isLoading,onUsernameChange:t.setUsername,onPasswordChange:t.setPassword,onCountryCodeChange:t.setCountryCode,onControlPinChange:t.setControlPin,onConnect:t.handleConnect}),t.isConnected&&t.connectedVin&&t.debugDump&&e.jsx(Re,{connectedVin:t.connectedVin,debugDump:t.debugDump,onClose:t.clearDebugDump})]}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},He=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),We=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),Ve=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),Ye=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),Ue=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),Oe=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),$e=()=>{const{t:a,i18n:t}=j(),{settings:o,updateSettings:m}=B(),g=i.useCallback(r=>{t.changeLanguage(r)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"flex flex-wrap gap-2",children:je.map(r=>e.jsxs("button",{role:"radio","aria-checked":t.language===r.code||t.language?.startsWith(r.code),onClick:()=>g(r.code),className:"py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 border "+(t.language===r.code||t.language?.startsWith(r.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"20px",height:"15px"},children:r.code==="gl"?e.jsx(He,{className:"w-full h-full rounded-sm"}):r.code==="ca"?e.jsx(We,{className:"w-full h-full rounded-sm"}):r.code==="eu"?e.jsx(Ve,{className:"w-full h-full rounded-sm"}):r.code==="es"?e.jsx(Ye,{className:"w-full h-full rounded-sm"}):r.code==="en"?e.jsx(Ue,{className:"w-full h-full rounded-sm"}):r.code==="pt"?e.jsx(Oe,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:r.flag})}),r.name]},r.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(r=>e.jsx("button",{role:"radio","aria-checked":o?.theme===r,onClick:()=>m({...o,theme:r}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(o?.theme===r?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(r==="auto"?"settings.themeAuto":r==="light"?"settings.themeLight":"settings.themeDark")},r))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:ye.filter(r=>r!=="overview").map(r=>{const d=(o.hiddenTabs||[]).includes(r);return e.jsxs("button",{onClick:()=>{const h=o.hiddenTabs||[],p=d?h.filter(s=>s!==r):[...h,r];m({...o,hiddenTabs:p})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(d?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${r}`)}),d?e.jsx(we,{className:"w-4 h-4"}):e.jsx(Ne,{className:"w-4 h-4"})]},r)})})]})]})]})},et=({onClose:a})=>{const{t}=j(),{googleSync:o,closeModal:m,openModal:g}=M(),{updateCar:r,activeCarId:d}=I(),{isNative:h}=Ce(),p=()=>{a?a():m("settings")};return e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(Se,{title:t("settings.title"),onClose:p}),e.jsxs("div",{className:"space-y-6 mt-4",children:[e.jsx(Te,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(ze,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Ae,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx($e,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(De,{googleSync:o}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),h&&e.jsxs(e.Fragment,{children:[e.jsx(Ie,{onConnectionChange:(s,l)=>{s&&l&&d?r(d,{vin:l,connectorType:"pybyd"}):!s&&d&&r(d,{vin:void 0,connectorType:void 0})}}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsxs("div",{className:"p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl flex items-center justify-between group",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800 flex items-center justify-center",children:e.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",className:"w-5 h-5 text-slate-600 dark:text-slate-400",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("circle",{cx:"12",cy:"12",r:"7"}),e.jsx("polyline",{points:"12 9 12 12 13.5 13.5"}),e.jsx("path",{d:"M16.51 17.35l-.35 3.83a2 2 0 0 1-2 1.82H9.84a2 2 0 0 1-2-1.82l-.35-3.83m9.02-10.7l.35-3.83a2 2 0 0 0-2-1.82H9.84a2 2 0 0 0-2 1.82l.35 3.83"})]})}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-bold text-slate-800 dark:text-white text-sm",children:t("modals.wearOs")}),e.jsx("p",{className:"text-xs text-slate-500",children:t("modals.wearOsInstall")})]})]}),e.jsx("button",{onClick:()=>m("settings"),onMouseDown:()=>g("wearOSSetup"),className:"px-4 py-2 bg-slate-800 dark:bg-slate-700 text-white rounded-xl text-xs font-bold hover:scale-105 transition-transform",children:"Configurar"})]})]})]}),e.jsx("button",{onClick:p,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:R},children:t("common.save")})]})})};export{et as default};
