const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./MfgDateModal-DMSQOFGS.js","./vendor-react-Dq1bEmBK.js","./vendor-i18n-BxxcNnpu.js","./vendor-capacitor-BCuo5VNy.js","./vendor-firebase-C8R0NUg4.js","./vendor-charts-B2MWdnDF.js","./index-DV_N1V7_.js","./index-LV-ziKmE.css","./AbrpHelpModal-D7-RgrYs.js","./BaseModal-Bk-yhavO.js"])))=>i.map(i=>d[i]);
import{u as T,R as I,j as e,r as i,n as ne,z as A}from"./vendor-react-Dq1bEmBK.js";import{l as J,e as Ne,L as we,R as Ce,D as Se,m as Pe,n as F,w as le,o as G,p as K,q as L,r as De,s as Ee,t as Te,v as Fe,x as R,Z as Ae,T as ze,y as Me,z as Ie,E as Ve,G as Be,I as _e,J as Re,K as Le,M as He,N as We,O as Ue,P as $e,Q as Oe,V as Ye,W as qe,X as Ge,Y as Je,_ as Ke,$ as Ze}from"./index-DV_N1V7_.js";import{_ as ie,C as Qe,r as Xe}from"./vendor-capacitor-BCuo5VNy.js";import{Y as et,U as tt,X as at,a2 as st,S as rt,Q as nt,a7 as Z,ae as oe,af as de,ab as lt,ac as it,a6 as ot}from"./vendor-firebase-C8R0NUg4.js";import{i as dt}from"./batteryCalculations-BaqeSYWG.js";import{B as ct}from"./BydVehiclePickerModal-DnYEV5pj.js";import{c as mt}from"./createLucideIcon-DdrpD-Gu.js";import"./vendor-i18n-BxxcNnpu.js";import"./vendor-charts-B2MWdnDF.js";const xt=({googleSync:a})=>{const{t}=T(),{openModal:d,exportSyncData:h}=J(),[g,v]=I.useState(!1),[u,p]=I.useState(!1);I.useEffect(()=>{v(!1)},[a.userProfile?.imageUrl]);const k=a.userProfile?.imageUrl,s=k&&!g;return e.jsxs("div",{className:"pt-4 border-t border-slate-200 dark:border-slate-700 mt-4",children:[e.jsxs("h4",{className:"text-sm font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2",children:[e.jsx(Ne,{className:"w-4 h-4 text-blue-500"}),t("settings.googleDrive")]}),a.error&&!a.isAuthenticated&&e.jsx("div",{className:"mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-600 dark:text-red-400 break-all",children:a.error}),a.isAuthenticated?e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-start justify-between gap-3 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-3 overflow-hidden",children:[s?e.jsx("img",{src:k,alt:"User",className:"w-10 h-10 rounded-full border border-slate-200 dark:border-slate-600",referrerPolicy:"no-referrer",onError:()=>v(!0)}):e.jsx("div",{className:"w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-800",children:a.userProfile?.name?.charAt(0)||"U"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-sm font-semibold text-slate-900 dark:text-white truncate flex items-center gap-2",children:a.userProfile?.name}),e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 truncate",children:a.userProfile?.email}),e.jsxs("div",{className:"flex items-center gap-1.5 mt-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full "+(a.isDriveReady?"bg-green-500 animate-pulse":"bg-amber-400")}),e.jsx("span",{className:"text-[10px] font-medium "+(a.isDriveReady?"text-green-600 dark:text-green-400":"text-amber-600 dark:text-amber-400"),children:a.isDriveReady?t("settings.connected"):t("settings.driveDisconnected","Drive desconectado")})]})]})]}),e.jsx("button",{onClick:a.logout,className:"p-2 -mr-2 rounded-xl text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors",title:t("settings.logout"),children:e.jsx(we,{className:"w-5 h-5"})})]}),!a.isDriveReady&&e.jsxs("div",{className:"mb-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl",children:[e.jsx("p",{className:"text-xs text-amber-700 dark:text-amber-400 font-medium mb-2",children:t("settings.driveSessionExpired","La sesión de Drive ha expirado")}),e.jsx("button",{onClick:a.login,className:"w-full py-2 px-3 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white transition-all active:scale-[0.98]",children:t("settings.reconnectDrive","Reconectar Google Drive")})]}),e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("button",{onClick:a.syncNow,disabled:a.isSyncing,className:"w-full py-3 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-md active:scale-[0.98] flex items-center justify-center gap-2 "+(a.isSyncing?"bg-blue-400 cursor-not-allowed":"bg-blue-600 hover:bg-blue-700 shadow-blue-500/20"),children:[e.jsx(Ce,{className:"w-4 h-4 "+(a.isSyncing?"animate-spin":"")}),a.isSyncing?t("settings.syncing"):t("settings.syncNow")]}),e.jsxs("button",{onClick:()=>d("backups"),className:"w-full py-3 px-4 rounded-xl text-sm font-medium bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]",children:[e.jsx(Se,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),t("settings.cloudBackups","Gestionar Copias en la Nube")]}),e.jsxs("button",{onClick:async()=>{p(!0);try{await h()}catch(n){F.error("Export failed:",n)}finally{p(!1)}},disabled:u,className:"w-full py-3 px-4 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] "+(u?"bg-slate-100 dark:bg-slate-700 text-slate-400 cursor-not-allowed":"bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-600"),children:[u?e.jsx("div",{className:"w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"}):e.jsx(Pe,{className:"w-4 h-4 text-slate-500 dark:text-slate-400"}),u?t("sync.exporting","Exportando..."):t("settings.exportData","Exportar Todos los Datos")]})]}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-[10px] text-slate-400 px-1",children:[e.jsx("span",{children:a.lastSyncTime?`${t("settings.lastSync")}: ${a.lastSyncTime.toLocaleTimeString()}`:t("sync.neverSynced","Nunca sincronizado")}),a.error&&e.jsx("span",{className:"text-red-500 truncate max-w-[150px]",title:a.error,children:a.error})]})]}):e.jsxs("button",{onClick:a.login,className:"w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-white border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600 font-medium rounded-xl px-4 py-3 transition-all shadow-sm active:scale-[0.98]",children:[e.jsxs("svg",{className:"w-5 h-5",viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z",fill:"#4285F4"}),e.jsx("path",{d:"M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",fill:"#34A853"}),e.jsx("path",{d:"M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z",fill:"#FBBC05"}),e.jsx("path",{d:"M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",fill:"#EA4335"})]}),t("settings.signInWithGoogle")]})]})},bt=I.lazy(()=>ie(()=>import("./MfgDateModal-DMSQOFGS.js"),__vite__mapDeps([0,1,2,3,4,5,6,7]),import.meta.url)),ut=()=>{const{t:a}=T(),{settings:t,updateSettings:d}=K(),{activeCar:h,updateCar:g,activeCarId:v,cars:u}=L(),{stats:p,aiSoH:k}=J(),[s,n]=i.useState(!1),{vehicles:m,loading:r}=(function(){const[l,b]=i.useState([]),[C,P]=i.useState(!0);return i.useEffect(()=>{let E=null,w=!1;return(async()=>{const S=await le();if(w||!S)return void P(!1);const D=et(at(G,"bydVehicles"),tt("userId","==",S));E=st(D,V=>{const M=[];V.forEach(H=>{const B=H.data();M.push({vin:H.id,modelName:B.modelName,vehicleType:B.vehicleType,lastSoC:B.lastSoC})}),b(M),P(!1)},V=>{F.warn("[useUserVehicles] snapshot error:",V),P(!1)})})(),()=>{w=!0,E?.()}},[]),{vehicles:l,loading:C}})(),[x,o]=i.useState(null),f=i.useMemo(()=>{const l=new Map;return m.forEach(b=>{l.set(b.vin,{vin:b.vin,label:b.modelName?`${b.modelName} · ${b.vin}`:b.vin})}),h?.vin&&!l.has(h.vin)&&l.set(h.vin,{vin:h.vin,label:h.vin}),Array.from(l.values())},[m,h?.vin]),y=p?.summary?.sohData,j=t?.sohMode||"manual";return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carModel",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carModel")}),e.jsxs("select",{id:"carModel",name:"carModel",value:t?.carModel||"",onChange:l=>d({...t,carModel:l.target.value,carColor:void 0}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600",children:[e.jsx("option",{value:"",children:a("settings.selectModel","Selecciona un modelo")}),De.map(({model:l})=>e.jsx("option",{value:l,children:l},l))]}),(()=>{const l=Ee(t?.carModel);return l?e.jsxs("div",{className:"mt-3",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carColor","Color del coche")}),e.jsx("div",{className:"flex flex-wrap gap-3",children:l.colors.map(b=>e.jsx("button",{onClick:()=>d({...t,carColor:b.id}),className:"w-8 h-8 rounded-full border-2 transition-all cursor-pointer shadow-sm "+(t?.carColor===b.id?"border-red-500 scale-110 shadow-md ring-2 ring-red-500/20":"border-slate-200 dark:border-slate-600 hover:scale-105"),style:{backgroundColor:b.hex},title:b.name,type:"button","aria-label":`Seleccionar color ${b.name}`},b.id))})]}):null})()]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carName",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.carName","Nombre del coche")}),e.jsx("input",{id:"carName",name:"carName",type:"text",value:h?.name||t?.carName||"",onChange:l=>{const b=l.target.value;d({...t,carName:b}),v&&g(v,{name:b})},placeholder:a("settings.carNamePlaceholder","Ej: Mi BYD Seal"),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"carVin",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.vin","VIN asociado")}),e.jsxs("select",{id:"carVin",name:"carVin",value:h?.vin||"",onChange:l=>(b=>{if(!v)return;const C=b||void 0;C&&u.forEach(P=>{P.id!==v&&P.vin===C&&g(P.id,{vin:void 0,connectorType:void 0})}),g(v,{vin:C,connectorType:C?"pybyd":void 0})})(l.target.value),disabled:!v||r&&f.length===0,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 font-mono text-sm disabled:opacity-50",children:[e.jsx("option",{value:"",children:a("settings.vinNone","Sin VIN asociado")}),f.map(l=>e.jsx("option",{value:l.vin,children:l.label},l.vin))]}),m.length>1&&e.jsxs("div",{className:"mt-4",children:[e.jsx("label",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.otherVehicles","Otros vehículos en tu cuenta")}),e.jsx("div",{className:"space-y-2",children:m.filter(l=>l.vin!==h?.vin).map(l=>e.jsxs("div",{className:"flex items-center justify-between bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700",children:[e.jsx("span",{className:"text-sm font-mono text-slate-700 dark:text-slate-300",children:l.vin}),e.jsx("button",{type:"button",disabled:x===l.vin,onClick:()=>(async b=>{if(confirm(`¿Estás seguro de que quieres desvincular y borrar de la nube el vehículo ${b}? Esta acción eliminará permanentemente su historial si no hiciste copia en Drive.`)){o(b);try{const C=rt(void 0,"europe-west1");await nt(C,"bydDetachVehicleV2")({vin:b}),ne.success(a("settings.vehicleDetached","Vehículo desvinculado correctamente")),h?.vin===b&&v&&g(v,{vin:void 0,connectorType:void 0})}catch(C){F.error("Error detaching vehicle:",C),ne.error(C.message||"Error al desvincular el vehículo")}finally{o(null)}}})(l.vin),className:"text-xs font-medium text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 disabled:opacity-50",children:x===l.vin?a("common.loading","Cargando..."):a("settings.detachVehicle","Desasociar de mi cuenta")})]},l.vin))})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"licensePlate",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.licensePlate")}),e.jsx("input",{id:"licensePlate",name:"licensePlate",type:"text",value:t?.licensePlate||"",onChange:l=>d({...t,licensePlate:l.target.value.toUpperCase()}),placeholder:"1234ABC",className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 uppercase"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"batterySize",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.batterySize")}),e.jsx("input",{id:"batterySize",name:"batterySize",type:"number",step:"0.01",value:t?.batterySize||0,onChange:l=>d({...t,batterySize:parseFloat(l.target.value)||0}),onBlur:async()=>{if(h?.vin)try{const l=Z(G,"bydVehicles",h.vin),b=typeof t.batterySize=="string"?parseFloat(t.batterySize):t.batterySize||0;if(!b||b<=0)return;await oe(l,{batteryCapacity:b,lastBatteryCapacity:b})}catch(l){F.error("Error syncing battery capacity:",l)}},className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-1",children:a("settings.sohMode")}),e.jsx("div",{className:"flex gap-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",role:"radiogroup","aria-label":a("settings.sohMode"),children:["manual","calculated","ai"].map(l=>e.jsx("button",{role:"radio","aria-checked":j===l,onClick:()=>{l!=="calculated"||t.mfgDate||n(!0),d({...t,sohMode:l})},className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(j===l?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),children:l==="ai"?"SoH IA":a(`settings.soh${l.charAt(0).toUpperCase()+l.slice(1)}`)},l))}),j==="manual"?e.jsxs("div",{className:"space-y-3",children:[e.jsx("label",{htmlFor:"soh",className:"sr-only",children:a("settings.sohMode")}),e.jsx("input",{id:"soh",name:"soh","aria-label":a("settings.sohMode"),type:"number",min:"0",max:"100",value:t?.soh||100,onChange:l=>d({...t,soh:parseInt(l.target.value)||100}),className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600"}),e.jsxs("button",{onClick:()=>n(!0),className:"w-full flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Te,{className:"w-4 h-4 text-slate-400"}),e.jsx("span",{className:"text-xs text-slate-600 dark:text-slate-400",children:a("settings.mfgDate")})]}),e.jsx("span",{className:"text-xs font-bold text-slate-700 dark:text-slate-300",children:t.mfgDateDisplay||a("common.notSet","No definida")})]})]}):j==="calculated"?e.jsx("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-4 space-y-3 border border-slate-100 dark:border-slate-700/50",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.estimatedSoh")}),e.jsxs("span",{className:"text-lg font-bold text-emerald-600 dark:text-emerald-400",children:[y?.estimated_soh||100,"%"]})]})}):e.jsx("div",{className:"bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-4 space-y-3 border border-indigo-100 dark:border-indigo-800/30",children:e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsx("span",{className:"text-xs text-indigo-600 dark:text-indigo-400 font-medium",children:a("settings.sohAi")}),e.jsxs("span",{className:"text-lg font-bold text-indigo-600 dark:text-indigo-400",children:[k?.toFixed(1)||100,"%"]})]})})]}),e.jsx(I.Suspense,{fallback:null,children:s&&e.jsx(bt,{isOpen:s,onClose:()=>n(!1),onSave:(l,b)=>{d({...t,mfgDate:l,mfgDateDisplay:b})},initialValue:t.mfgDateDisplay})})]})},gt=()=>{const{t:a}=T(),{settings:t,updateSettings:d}=K(),{activeCar:h}=L(),{charges:g}=(function(){const{charges:s}=J();return{charges:s}})(),{avgElectricPrice:v,avgFuelPrice:u,electricStats:p,fuelStats:k}=i.useMemo(()=>{if(!g||g.length===0)return{avgElectricPrice:0,avgFuelPrice:0,electricStats:{count:0,total:0,kwh:0},fuelStats:{count:0,total:0,liters:0}};const s=g.filter(y=>!y.type||y.type==="electric"),n=g.filter(y=>y.type==="fuel"),m=s.reduce((y,j)=>y+(j.totalCost||0),0),r=s.reduce((y,j)=>y+(j.kwhCharged||0),0),x=r>0?m/r:0,o=n.reduce((y,j)=>y+(j.totalCost||0),0),f=n.reduce((y,j)=>y+(j.litersCharged||0),0);return{avgElectricPrice:x,avgFuelPrice:f>0?o/f:0,electricStats:{count:s.length,total:m,kwh:r},fuelStats:{count:n.length,total:o,liters:f}}},[g]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"electricPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:[a("settings.electricityPrice")," (€/kWh)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const n=t.priceStrategy===s||!t.priceStrategy&&(s==="average"&&t.useCalculatedPrice||s==="custom"&&!t.useCalculatedPrice);return e.jsx("button",{onClick:()=>d({...t,priceStrategy:s,useCalculatedPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(n?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s!=="average"||g&&g.length!==0?"":a("settings.priceCalculatedNoData"),children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.priceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.priceStrategy!=="dynamic"&&e.jsx("input",{id:"electricPrice",name:"electricPrice",type:"number",step:"0.001",value:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?v.toFixed(3):t?.electricPrice||0,onChange:s=>d({...t,electricPrice:parseFloat(s.target.value)||0}),disabled:t.priceStrategy==="average"||t.useCalculatedPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.priceStrategy==="average"||t.useCalculatedPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice?a("settings.priceCalculatedAuto"):"0.15"}),(t.priceStrategy==="average"||!t.priceStrategy&&t.useCalculatedPrice)&&(p.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfo",{count:p.count,total:p.total.toFixed(2),kwh:p.kwh.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")}))]}),h?.isHybrid&&e.jsxs("div",{className:"space-y-2",children:[e.jsxs("label",{htmlFor:"fuelPrice",className:"block text-sm text-slate-600 dark:text-slate-400 mb-2 flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:"⛽"}),a("settings.fuelPrice")," (€/L)"]}),e.jsx("div",{className:"flex gap-2 mb-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-xl",children:["custom","average","dynamic"].map(s=>{const n=t.fuelPriceStrategy===s||!t.fuelPriceStrategy&&(s==="average"&&t.useCalculatedFuelPrice||s==="custom"&&!t.useCalculatedFuelPrice);return e.jsx("button",{onClick:()=>d({...t,fuelPriceStrategy:s,useCalculatedFuelPrice:s==="average"}),className:"flex-1 py-1.5 px-2 rounded-lg text-xs font-medium transition-all "+(n?"bg-white dark:bg-slate-600 text-slate-900 dark:text-white shadow-sm":"text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"),title:s==="average"&&k.count===0?a("settings.priceCalculatedNoData"):"",children:a(s==="custom"?"settings.priceCustom":s==="average"?"settings.priceCalculated":"settings.priceDynamics")},s)})}),t.fuelPriceStrategy==="dynamic"&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mb-2 italic",children:a("settings.priceDynamicsHint")}),t.fuelPriceStrategy!=="dynamic"&&e.jsx("input",{id:"fuelPrice",name:"fuelPrice",type:"number",step:"0.01",value:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?u.toFixed(3):t?.fuelPrice||1.5,onChange:s=>d({...t,fuelPrice:parseFloat(s.target.value)||1.5}),disabled:t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice,className:"w-full bg-slate-100 dark:bg-slate-700/50 text-slate-900 dark:text-white rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-600 "+(t.fuelPriceStrategy==="average"||t.useCalculatedFuelPrice?"opacity-60 cursor-not-allowed":""),placeholder:t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice?a("settings.priceCalculatedAuto"):"1.50"}),(t.fuelPriceStrategy==="average"||!t.fuelPriceStrategy&&t.useCalculatedFuelPrice)&&(k.count>0?e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400 mt-1",children:a("settings.priceCalculatedInfoFuel",{count:k.count,total:k.total.toFixed(2),liters:k.liters.toFixed(2)})}):e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:a("settings.priceCalculatedNoCharges")})),(!t.fuelPriceStrategy||t.fuelPriceStrategy==="custom")&&!t.useCalculatedFuelPrice&&e.jsx("p",{className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.fuelPriceHint")})]})]})},ht=()=>{const{t:a}=T(),{settings:t,updateSettings:d}=K(),{charges:h}=Fe(),g=i.useMemo(()=>{const s=t.batterySize,n=typeof s=="string"?parseFloat(s):Number(s);return n>0?n:0},[t.batterySize]),v=i.useMemo(()=>{if(!g||!h?.length)return{};const s={};for(const n of t.chargerTypes??[]){const m=dt(h,g,n.id);m&&(s[n.id]=m)}return s},[h,g,t.chargerTypes]),u=i.useCallback((s,n,m)=>{const r=[...t.chargerTypes||[]];r[s]={...r[s],[n]:m},d({...t,chargerTypes:r})},[t,d]),p=i.useCallback(()=>{const s={id:`custom_${Date.now()}`,name:a("settings.newChargerType"),speedKw:7.4,efficiency:.9},n=[...t.chargerTypes||[],s];d({...t,chargerTypes:n})},[t,d,a]),k=i.useCallback(s=>{const n=(t.chargerTypes||[]).filter((m,r)=>r!==s);d({...t,chargerTypes:n})},[t,d]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:R},children:e.jsx(Ae,{className:"w-4 h-4"})}),a("settings.chargerTypes")]}),(t?.chargerTypes||[]).map((s,n)=>{const m=`charger_${n}_name`,r=`charger_${n}_speed`,x=`charger_${n}_efficiency`,o=v[s.id],f=s?.efficiency||0,y=o&&Math.abs(o.value-f)>=.01;return e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("label",{htmlFor:m,className:"sr-only",children:a("settings.chargerName")}),e.jsx("input",{id:m,name:m,type:"text",value:s?.name||"",onChange:j=>u(n,"name",j.target.value),className:"flex-1 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:a("settings.chargerName")}),e.jsx("button",{onClick:()=>k(n),className:"p-2 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors",title:a("settings.deleteChargerType"),"aria-label":a("settings.deleteChargerType"),children:e.jsx(ze,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:r,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerSpeed")}),e.jsx("input",{id:r,name:r,type:"number",step:"0.1",value:s?.speedKw||0,onChange:j=>u(n,"speedKw",parseFloat(j.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:x,className:"text-xs text-slate-500 dark:text-slate-400",children:a("settings.chargerEfficiency")}),e.jsx("input",{id:x,name:x,type:"number",step:"0.01",min:"0",max:"1",value:s?.efficiency||0,onChange:j=>u(n,"efficiency",parseFloat(j.target.value)||0),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]}),y&&e.jsxs("div",{className:"flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700/50 rounded-lg px-3 py-1.5",children:[e.jsxs("span",{className:"text-xs text-amber-700 dark:text-amber-300",children:[a("settings.inferredEfficiency"),": ",e.jsxs("strong",{children:[(100*o.value).toFixed(1),"%"]}),e.jsxs("span",{className:"text-amber-500 dark:text-amber-400 ml-1",children:["(",o.sampleCount," ",a("settings.inferredCharges"),")"]})]}),e.jsx("button",{onClick:()=>u(n,"efficiency",o.value),className:"text-xs font-medium text-amber-700 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-100 underline underline-offset-2 ml-2",children:a("settings.applyInferred")})]})]},s.id)}),e.jsxs("button",{onClick:p,className:"w-full py-2 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:border-slate-400 dark:hover:border-slate-500 hover:text-slate-600 dark:hover:text-slate-300 transition-colors text-sm",children:["+ ",a("settings.addChargerType")]})]}),e.jsxs("div",{className:"space-y-3 pt-2 border-t border-slate-200 dark:border-slate-700",children:[e.jsxs("h3",{className:"text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2",children:[e.jsx("span",{style:{color:R},children:"⚡"}),a("settings.homeCharging","Carga Doméstica")]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 space-y-3",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"homeChargerRating",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.chargerRating","Potencia del Cargador (Amperios)")}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("input",{id:"homeChargerRating",name:"homeChargerRating",type:"number",value:t.homeChargerRating||8,onChange:s=>d({...t,homeChargerRating:parseInt(s.target.value)||0}),className:"w-20 bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"}),e.jsxs("span",{className:"text-xs text-slate-400",children:["≈ ",(230*(t.homeChargerRating||8)/1e3).toFixed(1)," kW"]})]}),e.jsx("p",{className:"text-[10px] text-slate-400 mt-1",children:"8A (1.8kW), 10A (2.3kW), 16A (3.7kW), 32A (7.4kW)"})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("label",{id:"offPeakLabel",className:"text-sm text-slate-700 dark:text-slate-300",children:a("settings.offPeakEnabled","Tarifa Valle (Horario Reducido)")}),e.jsx("button",{"aria-labelledby":"offPeakLabel",onClick:()=>{d({...t,offPeakEnabled:!t.offPeakEnabled})},className:"relative inline-flex h-6 w-11 items-center rounded-full transition-colors "+(t.offPeakEnabled?"bg-emerald-500":"bg-slate-300 dark:bg-slate-600"),children:e.jsx("span",{className:"inline-block h-4 w-4 transform rounded-full bg-white transition-transform "+(t.offPeakEnabled?"translate-x-6":"translate-x-1")})})]}),t.offPeakEnabled&&e.jsxs("div",{className:"space-y-3 pl-2 border-l-2 border-slate-200 dark:border-slate-600",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekday","Horario L-V")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStart",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStart",name:"offPeakStart",type:"time",value:t.offPeakStart||"00:00",onChange:s=>d({...t,offPeakStart:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEnd",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEnd",name:"offPeakEnd",type:"time",value:t.offPeakEnd||"08:00",onChange:s=>d({...t,offPeakEnd:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"block text-xs font-semibold text-slate-700 dark:text-slate-300",children:a("settings.offPeakWeekend","Horario Fin de Semana")}),e.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakStartWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.startTime","Inicio")}),e.jsx("input",{id:"offPeakStartWeekend",name:"offPeakStartWeekend",type:"time",value:t.offPeakStartWeekend||t.offPeakStart||"00:00",onChange:s=>d({...t,offPeakStartWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakEndWeekend",className:"block text-[10px] text-slate-500 dark:text-slate-400 mb-1",children:a("settings.endTime","Fin")}),e.jsx("input",{id:"offPeakEndWeekend",name:"offPeakEndWeekend",type:"time",value:t.offPeakEndWeekend||t.offPeakEnd||"08:00",onChange:s=>d({...t,offPeakEndWeekend:s.target.value}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600"})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"offPeakPrice",className:"block text-xs text-slate-500 dark:text-slate-400 mb-1",children:a("settings.offPeakPrice","Precio Valle (€/kWh)")}),e.jsx("input",{id:"offPeakPrice",name:"offPeakPrice",type:"number",step:"0.001",value:t.offPeakPrice||.05,onChange:s=>d({...t,offPeakPrice:parseFloat(s.target.value)||0}),className:"w-full bg-white dark:bg-slate-700 text-slate-900 dark:text-white rounded-lg px-3 py-2 text-sm border border-slate-200 dark:border-slate-600",placeholder:"0.05"})]})]})]})]})]})},pt=[{code:"ES",name:"España"},{code:"DE",name:"Germany"},{code:"FR",name:"France"},{code:"IT",name:"Italy"},{code:"NL",name:"Netherlands"},{code:"BE",name:"Belgium"},{code:"AT",name:"Austria"},{code:"PT",name:"Portugal"},{code:"SE",name:"Sweden"},{code:"NO",name:"Norway"},{code:"DK",name:"Denmark"},{code:"FI",name:"Finland"},{code:"GB",name:"United Kingdom"},{code:"IE",name:"Ireland"},{code:"CH",name:"Switzerland"},{code:"PL",name:"Poland"},{code:"CZ",name:"Czech Republic"},{code:"HU",name:"Hungary"}],ft=({username:a,password:t,countryCode:d,controlPin:h,isLoading:g,onUsernameChange:v,onPasswordChange:u,onCountryCodeChange:p,onControlPinChange:k,onConnect:s})=>{const{t:n}=T();return e.jsxs("div",{className:"connection-form",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-username",children:n("settings.emailLabel")}),e.jsx("input",{id:"byd-username",type:"email",value:a,onChange:m=>v(m.target.value),placeholder:n("settings.emailPlaceholder"),disabled:g})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-password",children:n("settings.passwordLabel")}),e.jsx("input",{id:"byd-password",type:"password",value:t,onChange:m=>u(m.target.value),placeholder:"••••••••",disabled:g})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-country",children:n("settings.countryLabel")}),e.jsx("select",{id:"byd-country",value:d,onChange:m=>p(m.target.value),disabled:g,children:pt.map(m=>e.jsx("option",{value:m.code,children:m.name},m.code))})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"byd-pin",children:n("settings.pinLabel")}),e.jsx("input",{id:"byd-pin",type:"password",value:h,onChange:m=>k(m.target.value),placeholder:"1234",maxLength:6,disabled:g}),e.jsx("span",{className:"form-hint",children:"Necesario para bloquear/desbloquear y control de clima"})]}),e.jsx("button",{className:"btn-connect",onClick:s,disabled:g||!a||!t,children:g?"Conectando...":"Conectar con BYD"})]})},vt=I.lazy(()=>ie(()=>import("./AbrpHelpModal-D7-RgrYs.js"),__vite__mapDeps([8,1,2,3,4,5,9,6,7]),import.meta.url).then(a=>({default:a.AbrpHelpModal}))),kt=({connectedVin:a,connectedVehicles:t,isLoading:d,autoRegisterCharges:h,heartbeatEnabled:g,hasAbrpToken:v,abrpToken:u,abrpSaving:p,onDisconnect:k,onAutoRegisterChange:s,onHeartbeatChange:n,onAbrpTokenChange:m,onSaveAbrpToken:r,onConnectionTap:x})=>{const{t:o}=T(),[f,y]=i.useState(!1),[j,l]=i.useState(""),[b,C]=i.useState(!1),P=Re(a),E=P?.controlPinStatus;return e.jsxs("div",{className:"mb-4",children:[e.jsxs("div",{className:"connection-status connected",style:{marginBottom:"1rem",cursor:"pointer",userSelect:"none"},onClick:x,title:"Toca 10 veces para API Dump",children:[e.jsx("span",{className:"status-icon",children:"✓"}),e.jsxs("div",{className:"status-info",children:[e.jsx("strong",{children:"Conectado"}),e.jsx("span",{className:"vin",children:a}),t.length>0&&e.jsx("span",{className:"vehicle-name",children:t[0].name||t[0].model})]})]}),e.jsx("button",{className:"btn-disconnect w-full",onClick:k,disabled:d,children:"Desconectar"}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:o("charges.autoRegisterTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:o("charges.autoRegisterDesc")})]}),e.jsx("input",{type:"checkbox",checked:h,onChange:w=>{const S=w.target.checked;s(S),localStorage.setItem("byd_auto_register_charges",String(S)),A.success(o(S?"charges.autoRegisterEnabled":"charges.autoRegisterDisabled"))},className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsx("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:e.jsxs("label",{className:"flex items-center justify-between cursor-pointer select-none",children:[e.jsxs("div",{children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200 mb-1",children:o("charges.locationWatchTitle")}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400",children:o("charges.locationWatchDesc")})]}),e.jsx("input",{type:"checkbox",checked:g,onChange:w=>(async S=>{n(S);try{await oe(Z(G,"bydVehicles",a),{heartbeatEnabled:S}),A.success(o(S?"charges.locationWatchEnabled":"charges.locationWatchDisabled"))}catch(D){F.error("Error updating heartbeatEnabled:",D),n(!S),A.error(o("errors.genericWithMessage",{message:D.message||o("errors.cannotSave")}))}})(w.target.checked),className:"toggle-checkbox w-11 h-6 cursor-pointer"})]})}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:o("settings.pin.title","PIN de control")}),E==="set"&&e.jsxs("span",{className:"text-xs font-medium text-green-600 dark:text-green-400",children:["✓ ",o("settings.pin.statusSet","Configurado")]}),E==="invalid"&&e.jsxs("span",{className:"text-xs font-medium text-red-600 dark:text-red-400",children:["✗ ",o("settings.pin.statusInvalid","Incorrecto")]}),(E==="not_set"||E===void 0)&&e.jsx("span",{className:"text-xs font-medium text-amber-600 dark:text-amber-400",children:o("settings.pin.statusNotSet","Sin configurar")})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:o("settings.pin.desc","Necesario para bloquear/desbloquear y controlar el clima. Sin él las acciones rápidas quedan desactivadas.")}),E==="invalid"&&e.jsx("div",{className:"mb-3 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg p-2",children:o("settings.pin.invalidWarning","El PIN guardado es incorrecto. Introdúcelo de nuevo.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:j,onChange:w=>l(w.target.value.replace(/\D/g,"").slice(0,6)),placeholder:E==="set"?o("settings.pin.placeholderChange","Escribe el PIN para cambiarlo"):o("settings.pin.placeholder","Ej. 123456"),inputMode:"numeric",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:async()=>{const w=j.trim();if(w){C(!0);try{await Le(a,w),l(""),A.success(o("settings.pin.saved","PIN de control guardado"))}catch(S){F.error("[BydIntegrationSettings] Error saving PIN:",S),A.error(o("errors.genericWithMessage",{message:S.message||o("errors.cannotSave")}))}finally{C(!1)}}},disabled:b||!j.trim(),className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:b?"...":o("common.save","Guardar")})]})]}),e.jsxs("div",{className:"mt-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700",children:[e.jsxs("div",{className:"flex items-center justify-between mb-1",children:[e.jsx("div",{className:"font-medium text-slate-700 dark:text-slate-200",children:"ABRP — A Better Route Planner"}),e.jsx("button",{onClick:()=>y(!0),"aria-label":o("abrp.help.buttonLabel","Ayuda para obtener el token de ABRP"),className:"w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-blue-100 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",children:"?"})]}),e.jsx("div",{className:"text-xs text-slate-500 dark:text-slate-400 mb-3",children:o("abrp.tokenDesc","Introduce tu token de ABRP para enviar telemetría en tiempo real.")}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{type:"password",value:u,onChange:w=>m(w.target.value),placeholder:v?o("abrp.tokenPlaceholderSet","Token guardado — escribe uno nuevo para reemplazar"):"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",className:"w-full px-3 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"}),e.jsx("button",{onClick:r,disabled:p,className:"self-start px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg disabled:opacity-50 transition-colors",children:p?"...":o("common.save","Guardar")})]}),v&&!u&&e.jsxs("div",{className:"mt-2 text-xs text-green-600 dark:text-green-400",children:["✓ ",o("abrp.telemetryActive","Telemetría ABRP activa")]})]}),e.jsx(I.Suspense,{fallback:null,children:f&&e.jsx(vt,{isOpen:f,onClose:()=>y(!1)})})]})},yt=({connectedVin:a,debugDump:t,onClose:d})=>{const{t:h}=T();return e.jsxs("div",{className:"diagnostic-display",style:{marginTop:"1rem"},children:[e.jsxs("h5",{children:["API Dump (Raw)",e.jsxs("div",{className:"dump-actions",children:[e.jsx("button",{className:"btn-copy",onClick:()=>{navigator.clipboard.writeText(JSON.stringify(t,null,2)),A.success(h("settings.debug.dumpCopied"))},children:"📋 Copiar"}),e.jsx("button",{className:"btn-close",onClick:d,children:"✕"})]})]}),e.jsx("div",{className:"dump-info",children:e.jsxs("small",{children:["Guardado en Firestore: ",e.jsxs("code",{children:["bydVehicles/",a,"/debug"]})]})}),e.jsx("pre",{className:"diagnostic-json",children:JSON.stringify(t,null,2)})]})},jt=({onConnectionChange:a})=>{const t=(u=>{const{t:p}=T(),[k,s]=i.useState(!1),[n,m]=i.useState(null),[r,x]=i.useState([]),[o,f]=i.useState(""),[y,j]=i.useState(""),[l,b]=i.useState("ES"),[C,P]=i.useState(""),[E,w]=i.useState(!1),[S,D]=i.useState(null),[V,M]=i.useState(null),[H,B]=i.useState(()=>localStorage.getItem("byd_auto_register_charges")==="true"),[ce,ee]=i.useState(!1),[me,te]=i.useState(!1),[Q,ae]=i.useState(""),[xe,se]=i.useState(!1),[be,W]=i.useState(null),[ue,U]=i.useState(null),$=i.useRef(0),_=i.useRef(null),O=i.useRef(u);O.current=u,i.useEffect(()=>{const c=localStorage.getItem("byd_connected_vin"),N=localStorage.getItem("byd_connected_vehicles");if(c&&(m(c),s(!0),O.current?.(!0,c)),N)try{x(JSON.parse(N))}catch{}},[]),i.useEffect(()=>{n&&de(Z(G,"bydVehicles",n)).then(c=>{c.exists()&&(ee(c.data().heartbeatEnabled===!0),te(c.data().hasAbrpToken===!0))}).catch(()=>{})},[n]);const ge=i.useCallback(async()=>{if(n){se(!0);try{const c=Q.trim();await Me(n,c),te(!!c),ae(""),A.success(p(c?"settings.abrp.tokenSaved":"settings.abrp.tokenRemoved"))}catch(c){F.error("Error saving ABRP token:",c),A.error(p("settings.abrp.tokenError"))}finally{se(!1)}}},[n,Q,p]),Y=i.useCallback((c,N)=>{m(c),x(N),s(!0),localStorage.setItem("byd_connected_vin",c),localStorage.setItem("byd_connected_vehicles",JSON.stringify(N));const z=N.find(X=>X.vin===c);M(`Conectado: ${z?.name||z?.model||c}`),j(""),P(""),O.current?.(!0,c)},[]),he=i.useCallback(c=>{U(N=>N&&N.find(z=>z.vin===c)?(Y(c,N),null):N)},[Y]),pe=i.useCallback(c=>{U(N=>{if(!N)return N;const z=N.find(je=>je.vin===c);if(!z)return N;m(c),x(N),s(!0),localStorage.setItem("byd_connected_vin",c),localStorage.setItem("byd_connected_vehicles",JSON.stringify(N));const X=z.name||z.model||c;return M(`Conectado: ${X}`),j(""),P(""),null})},[]),fe=i.useCallback(()=>{U(null)},[]),ve=i.useCallback(async()=>{if(o&&y){w(!0),D(null),M(null);try{const c=await le()||"dev-user",N=await Ie(o,y,l,C||void 0,c);N.success&&N.vehicles.length>0?N.vehicles.length===1?Y(N.vehicles[0].vin,N.vehicles):U(N.vehicles):D("No se encontraron vehículos en la cuenta")}catch(c){F.error("BYD connect error:",c),D(c instanceof Error?c.message:"Error al conectar con BYD")}finally{w(!1)}}else D("Por favor introduce usuario y contraseña")},[o,y,l,C,Y]),ke=i.useCallback(async()=>{if(n){w(!0),D(null);try{await Ve(n),m(null),x([]),s(!1),W(null),localStorage.removeItem("byd_connected_vin"),localStorage.removeItem("byd_connected_vehicles"),localStorage.removeItem("byd_auto_register_charges"),M("Desconectado correctamente"),O.current?.(!1)}catch(c){F.error("BYD disconnect error:",c),D(c instanceof Error?c.message:"Error al desconectar")}finally{w(!1)}}},[n]),re=i.useCallback(async()=>{if(n){w(!0),D(null),W(null);try{const c=await Be(n);c.success?(W(c.dump),A.success(p("settings.debug.dumpSuccess"))):D("Error al obtener dump")}catch(c){F.error("BYD dump error:",c),D(c instanceof Error?c.message:"Error al obtener dump")}finally{w(!1)}}},[n,p]),ye=i.useCallback(()=>{$.current+=1;const c=$.current;_.current&&clearTimeout(_.current),_.current=setTimeout(()=>{$.current=0},_e),c>=10&&($.current=0,_.current&&clearTimeout(_.current),re())},[re]);return{isConnected:k,connectedVin:n,connectedVehicles:r,username:o,password:y,countryCode:l,controlPin:C,setUsername:f,setPassword:j,setCountryCode:b,setControlPin:P,isLoading:E,error:S,success:V,autoRegisterCharges:H,setAutoRegisterCharges:B,heartbeatEnabled:ce,setHeartbeatEnabled:ee,hasAbrpToken:me,abrpToken:Q,setAbrpToken:ae,abrpSaving:xe,debugDump:be,clearDebugDump:i.useCallback(()=>W(null),[]),pendingVehicles:ue,selectVehicle:he,selectVehiclesSilent:pe,cancelVehicleSelection:fe,handleConnect:ve,handleDisconnect:ke,handleSaveAbrpToken:ge,handleConnectionTap:ye}})(a),{cars:d,addCar:h,updateCar:g}=L(),v=i.useCallback(u=>{u.length!==0&&(u.forEach(({vin:p,target:k,vehicle:s})=>{d.forEach(n=>{n.vin===p&&n.id!==k&&g(n.id,{vin:void 0,connectorType:void 0})}),k==="new"?h({name:s.name||s.model||"BYD",vin:p,type:"ev",isHybrid:!1,connectorType:"pybyd"}):g(k,{vin:p,connectorType:"pybyd"})}),t.selectVehiclesSilent(u[0].vin))},[d,h,g,t]);return e.jsxs("div",{className:"byd-settings",children:[e.jsxs("div",{className:"settings-section",children:[e.jsxs("h3",{className:"settings-title",children:[e.jsx("span",{className:"icon",children:"🚗"}),"BYD Direct API",e.jsx("span",{className:"badge beta",children:"BETA"})]}),t.isConnected&&t.connectedVin&&e.jsx(kt,{connectedVin:t.connectedVin,connectedVehicles:t.connectedVehicles,isLoading:t.isLoading,autoRegisterCharges:t.autoRegisterCharges,heartbeatEnabled:t.heartbeatEnabled,hasAbrpToken:t.hasAbrpToken,abrpToken:t.abrpToken,abrpSaving:t.abrpSaving,onDisconnect:t.handleDisconnect,onAutoRegisterChange:t.setAutoRegisterCharges,onHeartbeatChange:t.setHeartbeatEnabled,onAbrpTokenChange:t.setAbrpToken,onSaveAbrpToken:t.handleSaveAbrpToken,onConnectionTap:t.handleConnectionTap}),t.error&&e.jsxs("div",{className:"message error",children:[e.jsx("span",{className:"icon",children:"⚠️"}),t.error]}),t.success&&e.jsxs("div",{className:"message success",children:[e.jsx("span",{className:"icon",children:"✓"}),t.success]}),!t.isConnected&&e.jsx(ft,{username:t.username,password:t.password,countryCode:t.countryCode,controlPin:t.controlPin,isLoading:t.isLoading,onUsernameChange:t.setUsername,onPasswordChange:t.setPassword,onCountryCodeChange:t.setCountryCode,onControlPinChange:t.setControlPin,onConnect:t.handleConnect}),t.isConnected&&t.connectedVin&&t.debugDump&&e.jsx(yt,{connectedVin:t.connectedVin,debugDump:t.debugDump,onClose:t.clearDebugDump})]}),t.pendingVehicles&&e.jsx(ct,{vehicles:t.pendingVehicles,existingCars:d.map(u=>({id:u.id,name:u.name,vin:u.vin})),onConfirm:v,onCancel:t.cancelVehicleSelection}),e.jsx("style",{children:`
                .byd-settings {
                    padding: 1rem;
                }

                .settings-section {
                    background: #ffffff;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .dark .settings-section {
                    background: #1e293b;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                }

                .settings-title {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 0 0.5rem 0;
                    font-size: 1.25rem;
                    color: #1f2937;
                }

                .dark .settings-title {
                    color: #f1f5f9;
                }

                .settings-title .icon {
                    font-size: 1.5rem;
                }

                .badge.beta {
                    background: #ff9800;
                    color: white;
                    font-size: 0.6rem;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-weight: bold;
                }

                .settings-description {
                    color: #6b7280;
                    font-size: 0.9rem;
                    margin-bottom: 1.5rem;
                }

                .dark .settings-description {
                    color: #94a3b8;
                }

                .connection-status {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    padding: 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                }

                .connection-status.connected {
                    background: #dcfce7;
                    border: 1px solid #4ade80;
                }

                .dark .connection-status.connected {
                    background: rgba(34, 197, 94, 0.15);
                    border: 1px solid #22c55e;
                }

                .status-icon {
                    font-size: 1.5rem;
                    color: #22c55e;
                }

                .status-info {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                    min-width: 0;
                }

                .status-info strong {
                    color: #166534;
                }

                .dark .status-info strong {
                    color: #4ade80;
                }

                .status-info .vin {
                    font-family: monospace;
                    font-size: 0.8rem;
                    color: #6b7280;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                .dark .status-info .vin {
                    color: #94a3b8;
                }

                .status-info .vehicle-name {
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .status-info .vehicle-name {
                    color: #94a3b8;
                }

                .message {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1rem;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }

                .message.error {
                    background: #fee2e2;
                    color: #dc2626;
                    border: 1px solid #f87171;
                }

                .dark .message.error {
                    background: rgba(220, 38, 38, 0.15);
                    color: #f87171;
                    border: 1px solid rgba(248, 113, 113, 0.3);
                }

                .message.success {
                    background: #dcfce7;
                    color: #16a34a;
                    border: 1px solid #4ade80;
                }

                .dark .message.success {
                    background: rgba(34, 197, 94, 0.15);
                    color: #4ade80;
                    border: 1px solid rgba(74, 222, 128, 0.3);
                }

                .connection-form {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .form-group label {
                    font-size: 0.9rem;
                    font-weight: 500;
                    color: #374151;
                }

                .dark .form-group label {
                    color: #e2e8f0;
                }

                .form-group input,
                .form-group select {
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 1rem;
                    background: #ffffff;
                    color: #1f2937;
                }

                .dark .form-group input,
                .dark .form-group select {
                    background: #0f172a;
                    border-color: #334155;
                    color: #f1f5f9;
                }

                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
                }

                .form-group input::placeholder {
                    color: #9ca3af;
                }

                .dark .form-group input::placeholder {
                    color: #64748b;
                }

                .form-hint {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .form-hint {
                    color: #94a3b8;
                }

                .btn-connect,
                .btn-disconnect {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }

                .btn-connect {
                    background: #3b82f6;
                    color: white;
                }

                .btn-connect:hover:not(:disabled) {
                    background: #2563eb;
                }

                .btn-connect:disabled {
                    background: #9ca3af;
                    cursor: not-allowed;
                }

                .dark .btn-connect:disabled {
                    background: #475569;
                }

                .btn-disconnect {
                    background: #ef4444;
                    color: white;
                    flex-shrink: 0;
                }

                .btn-disconnect:hover:not(:disabled) {
                    background: #dc2626;
                }

                .connected-actions {
                    margin-top: 1.5rem;
                }

                .connected-actions h4 {
                    margin: 0 0 1rem 0;
                    font-size: 1rem;
                    color: #374151;
                }

                .dark .connected-actions h4 {
                    color: #e2e8f0;
                }

                .action-buttons {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }

                .btn-action {
                    padding: 0.5rem 1rem;
                    background: #f3f4f6;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    color: #374151;
                }

                .dark .btn-action {
                    background: #334155;
                    border-color: #475569;
                    color: #e2e8f0;
                }

                .btn-action:hover:not(:disabled) {
                    background: #e5e7eb;
                }

                .dark .btn-action:hover:not(:disabled) {
                    background: #475569;
                }

                .btn-action:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }

                .data-display {
                    background: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                }

                .dark .data-display {
                    background: #0f172a;
                    border-color: #334155;
                }

                .data-display h5 {
                    margin: 0 0 0.75rem 0;
                    font-size: 0.9rem;
                    color: #6b7280;
                }

                .dark .data-display h5 {
                    color: #94a3b8;
                }

                .data-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    gap: 0.75rem;
                }

                .data-item {
                    display: flex;
                    flex-direction: column;
                    gap: 0.25rem;
                }

                .data-item .label {
                    font-size: 0.75rem;
                    color: #6b7280;
                }

                .dark .data-item .label {
                    color: #94a3b8;
                }

                .data-item .value {
                    font-size: 1rem;
                    font-weight: 500;
                    color: #1f2937;
                }

                .dark .data-item .value {
                    color: #f1f5f9;
                }

                .btn-map {
                    display: inline-block;
                    margin-top: 0.75rem;
                    padding: 0.5rem 1rem;
                    background: #3b82f6;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-size: 0.9rem;
                }

                .btn-map:hover {
                    background: #2563eb;
                }

                .diagnostic-display {
                    margin-top: 1rem;
                }

                .diagnostic-display h5 {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 0 0 0.5rem 0;
                    color: #374151;
                }

                .dark .diagnostic-display h5 {
                    color: #e2e8f0;
                }

                .btn-close {
                    background: none;
                    border: none;
                    font-size: 1.25rem;
                    cursor: pointer;
                    color: #6b7280;
                }

                .dark .btn-close {
                    color: #94a3b8;
                }

                .btn-close:hover {
                    color: #374151;
                }

                .dark .btn-close:hover {
                    color: #e2e8f0;
                }

                .diagnostic-json {
                    background: #1e293b;
                    color: #a3e635;
                    padding: 1rem;
                    border-radius: 8px;
                    font-size: 0.75rem;
                    overflow-x: auto;
                    max-height: 400px;
                }
            `})]})},Nt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"white"}),e.jsx("path",{d:"M0,0 L0,160 L427,480 L640,480 L640,320 L213,0 Z",fill:"#0092E6"})]}),wt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#FFED00"}),e.jsx("rect",{y:"48",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"144",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"240",width:"640",height:"48",fill:"#DA121A"}),e.jsx("rect",{y:"336",width:"640",height:"48",fill:"#DA121A"})]}),Ct=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#d52b1e",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#fff",d:"M0 200h640v80H0z"}),e.jsx("path",{fill:"#fff",d:"M280 0h80v480h-80z"}),e.jsx("path",{fill:"#009b48",d:"m0 0 640 480h-80L0 80z"}),e.jsx("path",{fill:"#009b48",d:"M560 0 0 420v60L640 60V0z"})]}),St=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#AA151B"}),e.jsx("rect",{width:"640",height:"240",y:"120",fill:"#F1BF00"})]}),Pt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{fill:"#012169",d:"M0 0h640v480H0z"}),e.jsx("path",{fill:"#FFF",d:"M75 0 0 53v28L640 480h-87l-75-53v28L0 0h75zM640 0v53L0 480v-28L640 0z"}),e.jsx("path",{fill:"#C8102E",d:"m424 286 216 144v50L424 286zm-208-92L0 50V0l216 194zM0 480l216-144v-50L0 480zm640 0L424 286l216-144v144z"}),e.jsx("path",{fill:"#FFF",d:"M250 0h140v480H250zM0 170h640v140H0z"}),e.jsx("path",{fill:"#C8102E",d:"M280 0h80v480h-80zM0 200h640v80H0z"})]}),Dt=({className:a})=>e.jsxs("svg",{viewBox:"0 0 640 480",className:a,xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("rect",{width:"640",height:"480",fill:"#C60C30"}),e.jsx("rect",{width:"240",height:"480",fill:"#006600"}),e.jsx("circle",{cx:"240",cy:"240",r:"80",fill:"#FFC400"}),e.jsx("circle",{cx:"240",cy:"240",r:"70",fill:"#FFF"}),e.jsx("path",{fill:"#006600",d:"M190 240 a50 50 0 0 1 100 0 h-10 a40 40 0 0 0 -80 0 z"}),e.jsx("rect",{x:"220",y:"190",width:"40",height:"50",fill:"#C60C30"})]}),Et=()=>{const{t:a,i18n:t}=T(),{settings:d,updateSettings:h}=K(),g=Qe.isNativePlatform(),[v,u]=i.useState(He),[p,k]=i.useState(We),s=i.useCallback(r=>{Ue(r),u(r)},[]),n=i.useCallback(r=>{$e(r),k(r)},[]),m=i.useCallback(r=>{t.changeLanguage(r),Oe(r)},[t]);return e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.language")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.language"),className:"flex flex-wrap gap-2",children:Ye.map(r=>e.jsxs("button",{role:"radio","aria-checked":t.language===r.code||t.language?.startsWith(r.code),onClick:()=>m(r.code),className:"py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2 border "+(t.language===r.code||t.language?.startsWith(r.code)?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:[e.jsx("span",{className:"inline-flex items-center justify-center",style:{width:"20px",height:"15px"},children:r.code==="gl"?e.jsx(Nt,{className:"w-full h-full rounded-sm"}):r.code==="ca"?e.jsx(wt,{className:"w-full h-full rounded-sm"}):r.code==="eu"?e.jsx(Ct,{className:"w-full h-full rounded-sm"}):r.code==="es"?e.jsx(St,{className:"w-full h-full rounded-sm"}):r.code==="en"?e.jsx(Pt,{className:"w-full h-full rounded-sm"}):r.code==="pt"?e.jsx(Dt,{className:"w-full h-full rounded-sm"}):e.jsx("span",{className:"text-lg leading-none",children:r.flag})}),r.name]},r.code))})]}),e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.theme")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.theme"),className:"flex gap-2",children:["auto","light","dark"].map(r=>e.jsx("button",{role:"radio","aria-checked":d?.theme===r,onClick:()=>h({...d,theme:r}),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(d?.theme===r?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:a(r==="auto"?"settings.themeAuto":r==="light"?"settings.themeLight":"settings.themeDark")},r))}),e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.customizeTabs")}),e.jsx("div",{className:"grid grid-cols-2 gap-2",children:qe.filter(r=>r!=="overview").map(r=>{const x=(d.hiddenTabs||[]).includes(r);return e.jsxs("button",{onClick:()=>{const o=d.hiddenTabs||[],f=x?o.filter(y=>y!==r):[...o,r];h({...d,hiddenTabs:f})},className:"flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-colors border "+(x?"bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-600":"byd-active-item"),children:[e.jsx("span",{children:a(`tabs.${r}`)}),x?e.jsx(Je,{className:"w-4 h-4"}):e.jsx(Ge,{className:"w-4 h-4"})]},r)})})]})]}),g&&e.jsxs("div",{children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.biometric","Bloqueo de la aplicación")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.biometric"),className:"flex gap-2",children:[!0,!1].map(r=>e.jsx("button",{role:"radio","aria-checked":v===r,onClick:()=>s(r),className:"flex-1 py-2 px-4 rounded-xl text-sm font-medium transition-colors border "+(v===r?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:r?a("settings.biometricOn","Activado"):a("settings.biometricOff","Desactivado")},String(r)))}),v&&e.jsxs("div",{className:"mt-4",children:[e.jsx("p",{className:"block text-sm text-slate-600 dark:text-slate-400 mb-2",children:a("settings.biometricMode","Método de verificación")}),e.jsx("div",{role:"radiogroup","aria-label":a("settings.biometricMode"),className:"flex gap-2",children:[{value:"biometric",label:a("settings.biometricModeHuella","🫆 Biométrico")},{value:"pin",label:a("settings.biometricModePin","🔢 PIN / Patrón")}].map(({value:r,label:x})=>e.jsx("button",{role:"radio","aria-checked":p===r,onClick:()=>n(r),className:"flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-colors border "+(p===r?"byd-active-item":"bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"),children:x},r))}),e.jsx("p",{className:"text-xs text-slate-400 dark:text-slate-500 mt-2",children:p==="biometric"?a("settings.biometricModeHuellaDesc","Usa huella o reconocimiento facial al abrir la app"):a("settings.biometricModePinDesc","Usa el PIN o patrón del teléfono al abrir la app")})]})]})]})},q=Xe("BluetoothTracker"),Tt=mt("shield-alert",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]),Ft=()=>{const{t:a}=T(),{activeCarId:t,cars:d}=L(),[h,g]=i.useState([]),[v,u]=i.useState(""),[p,k]=i.useState(!1),[s,n]=i.useState(!1),m=d.find(x=>x.id===t);i.useEffect(()=>{r()},[t]);const r=async()=>{try{const x=await q.getTargetDevice();x.mac?(u(x.mac),k(!0)):(k(!1),u(""))}catch(x){console.error("Failed to load BT settings",x)}};return m?.vin?e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2",children:[e.jsx("div",{className:"p-2 rounded-xl",style:{backgroundColor:`${R}15`,color:R},children:e.jsx(Tt,{className:"w-5 h-5"})}),e.jsx("h3",{className:"text-lg font-semibold text-slate-800 dark:text-white",children:a("settings.security.title","Seguridad y Bluetooth")})]}),e.jsx("p",{className:"text-sm text-slate-600 dark:text-slate-400",children:a("settings.security.btDescription","Aviso al alejarte si el coche queda abierto o desprotegido al desconectar el Bluetooth.")}),e.jsxs("div",{className:"flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700",children:[e.jsx("div",{className:"flex flex-col",children:e.jsx("span",{className:"font-medium text-slate-800 dark:text-white",children:a("settings.security.btAlerts","Avisos Bluetooth")})}),e.jsxs("label",{className:"relative inline-flex items-center cursor-pointer",children:[e.jsx("input",{type:"checkbox",className:"sr-only peer",checked:p,onChange:x=>(async o=>{if(!o)return await q.setTargetDevice({mac:"",vin:""}),k(!1),void u("");n(!0);try{const f=await q.getPairedDevices();g(f.devices||[]),k(!0)}catch(f){alert(f.message||"Permiso denegado o Bluetooth no disponible"),k(!1)}finally{n(!1)}})(x.target.checked),disabled:s}),e.jsx("div",{className:"w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"})]})]}),p&&h.length>0&&e.jsxs("div",{className:"p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3",children:[e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-300",children:a("settings.security.selectDevice","Selecciona el Bluetooth del coche:")}),e.jsxs("select",{className:"w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg p-2.5 text-slate-800 dark:text-white",value:v,onChange:x=>(async o=>{if(m?.vin){n(!0);try{const f=m.vin,y=lt(it()),j=Z(y,"bydVehicles",f,"private","integration");let b=(await de(j)).data()?.btSecurityToken;b||(b=crypto.randomUUID(),await ot(j,{btSecurityToken:b},{merge:!0})),await q.setTargetDevice({mac:o,vin:f,token:b}),u(o)}catch(f){console.error(f),alert("Error guardando configuración")}finally{n(!1)}}})(x.target.value),disabled:s,children:[e.jsx("option",{value:"",children:a("common.select","Seleccionar...")}),h.map(x=>e.jsx("option",{value:x.mac,children:x.name||x.mac},x.mac))]})]})]}):null},Ht=({onClose:a})=>{const{t}=T(),{googleSync:d,closeModal:h}=J(),{cars:g,activeCarId:v,updateCar:u,addCar:p,setActiveCarId:k}=L(),{isNative:s}=Ke(),n=()=>{a?a():h("settings")};return e.jsx("div",{className:"fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative",children:[e.jsx(Ze,{title:t("settings.title"),onClose:n}),e.jsxs("div",{className:"space-y-6 mt-4",children:[e.jsx(ut,{}),e.jsx(gt,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(ht,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(Et,{}),e.jsx(xt,{googleSync:d}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),s&&e.jsxs(e.Fragment,{children:[e.jsx(Ft,{}),e.jsx("div",{className:"border-t border-slate-200 dark:border-slate-700 my-4"}),e.jsx(jt,{onConnectionChange:(m,r)=>{if(!m){const f=g.find(y=>y.connectorType==="pybyd");return void(f&&u(f.id,{vin:void 0,connectorType:void 0}))}if(!r)return;const x=g.find(f=>f.vin===r);if(x)return v!==x.id&&k(x.id),x.connectorType!=="pybyd"&&u(x.id,{connectorType:"pybyd"}),void g.forEach(f=>{f.id!==x.id&&f.vin===r&&u(f.id,{vin:void 0,connectorType:void 0})});const o=v?g.find(f=>f.id===v):void 0;o&&!o.vin?u(o.id,{vin:r,connectorType:"pybyd"}):p({name:"BYD",vin:r,type:"ev",isHybrid:!1,connectorType:"pybyd"})}})]})]}),e.jsx("button",{onClick:n,className:"w-full mt-6 py-3 rounded-xl font-medium text-white shadow-lg shadow-red-500/20 active:scale-[0.98] transition-transform",style:{backgroundColor:R},children:t("common.save")})]})})};export{Ht as default};
